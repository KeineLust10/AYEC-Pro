"""Validated, restart-only SQLite restore shared by desktop products."""

from contextlib import closing
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3


def _validate(path, required_tables=()):
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as conn:
        if conn.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise ValueError("Backup integrity check failed")
        tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not set(required_tables).issubset(tables):
            raise ValueError("Backup schema does not match this product")


def stage_restore(command, local_db, download, *, product_code, required_tables=()):
    payload = dict(command.get("payload") or {})
    backup_id = int(payload.get("backup_id") or 0)
    if command.get("command_type") != "restore_backup" or backup_id <= 0:
        raise ValueError("Unsupported restore command")
    if payload.get("product_code", product_code) != product_code:
        raise ValueError("Restore belongs to another product")
    target = Path(local_db).expanduser().resolve()
    staged = target.with_suffix(target.suffix + ".pending-restore")
    marker = target.with_suffix(target.suffix + ".pending-restore.json")
    if marker.exists():
        previous = json.loads(marker.read_text(encoding="utf-8"))
        if previous.get("command_id") == int(command.get("id") or 0):
            return {"backup_id": backup_id, "restart_required": True}
        raise ValueError("Another restore is already awaiting restart")
    raw = download(backup_id)
    if not raw.startswith(b"SQLite format 3\x00"):
        raise ValueError("Backup is not a SQLite database")
    digest = hashlib.sha256(raw).hexdigest()
    if payload.get("sha256") and not secrets.compare_digest(digest, str(payload["sha256"])):
        raise ValueError("Downloaded backup checksum mismatch")
    temporary = staged.with_suffix(staged.suffix + ".tmp")
    try:
        temporary.write_bytes(raw)
        _validate(temporary, required_tables)
        os.replace(temporary, staged)
    finally:
        temporary.unlink(missing_ok=True)
    metadata = {"command_id": int(command.get("id") or 0), "backup_id": backup_id,
                "sha256": digest, "staged_path": str(staged), "product_code": product_code}
    temporary_marker = marker.with_suffix(".json.tmp")
    temporary_marker.write_text(json.dumps(metadata, ensure_ascii=True), encoding="utf-8")
    os.replace(temporary_marker, marker)
    return {"backup_id": backup_id, "sha256": digest, "restart_required": True}


def apply_pending_restore(database_path, *, product_code=None, required_tables=()):
    """Call before any application connection opens the database."""
    target = Path(database_path).expanduser().resolve()
    marker = target.with_suffix(target.suffix + ".pending-restore.json")
    if not marker.exists():
        return {"applied": False}
    metadata = json.loads(marker.read_text(encoding="utf-8"))
    staged = target.with_suffix(target.suffix + ".pending-restore")
    if Path(str(metadata.get("staged_path") or "")).resolve() != staged or not staged.is_file():
        raise ValueError("Pending restore file is unavailable")
    if product_code and metadata.get("product_code", product_code) != product_code:
        raise ValueError("Pending restore belongs to another product")
    if not secrets.compare_digest(hashlib.sha256(staged.read_bytes()).hexdigest(), str(metadata.get("sha256") or "")):
        raise ValueError("Pending restore checksum validation failed")
    _validate(staged, required_tables)
    before = target.with_name(f"{target.stem}.before-remote-restore-{datetime.now():%Y%m%d-%H%M%S-%f}{target.suffix}")
    if target.exists():
        with closing(sqlite3.connect(target, timeout=30)) as source:
            with closing(sqlite3.connect(before, timeout=30)) as destination:
                source.backup(destination)
            # Checkpoint the old WAL before replacing the main database.
            result = source.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            if result and result[0]:
                raise ValueError("Database is busy; restore requires all connections closed")
    os.replace(staged, target)
    marker.unlink(missing_ok=True)
    for suffix in ("-wal", "-shm"):
        Path(str(target) + suffix).unlink(missing_ok=True)
    return {"applied": True, "command_id": int(metadata.get("command_id") or 0),
            "backup_id": int(metadata.get("backup_id") or 0),
            "before_backup": str(before) if before.exists() else ""}
