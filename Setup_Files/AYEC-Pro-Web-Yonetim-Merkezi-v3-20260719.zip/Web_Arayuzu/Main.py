"""AYEC Pro masaustu uygulamasinin yerel web sunucusu ve SQLite koprusu."""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import html
import io
import importlib.util
import json
import mimetypes
import os
import re
import secrets
import shutil
import smtplib
import sqlite3
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import unicodedata
import zipfile
import zlib
from contextlib import closing
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from pathlib import Path, PureWindowsPath
from urllib.parse import parse_qs, unquote, urlparse
from urllib.request import Request, urlopen
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parent
WEB_ROOT = ROOT / "web"
DIALOGS_MANIFEST = WEB_ROOT / "dialogs.generated.json"
_configured_db = os.environ.get("AYEC_DB_PATH", "").strip()
DB_PATH = (
    (ROOT / _configured_db).resolve()
    if _configured_db and not Path(_configured_db).is_absolute()
    else Path(_configured_db).expanduser().resolve()
    if _configured_db
    else Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "AYEC Pro" / "ayecpro.db"
)
# The registry database remains the compatibility entry point.  Operational
# data is routed to one database per company under this directory.
TENANT_ROOT = Path(os.environ.get("AYEC_TENANT_DIR", str(ROOT / "Kullanıcılar"))).expanduser().resolve()

SESSION_COOKIE = "ayec_session"
PASSWORD_ITERATIONS = 310_000
_SCHEMA_LOCK = threading.Lock()
_SCHEMA_READY_PATHS: set[str] = set()
_TENANT_LOCAL = threading.local()
_AUTH_LOCK = threading.Lock()
_AUTH_FAILURES: dict[str, list[float]] = {}

TABLES = {
    "customers", "customer_currency_balances", "customer_notes", "customer_services",
    "devices", "used_parts", "parts", "stock_movements", "services", "service_definitions",
    "appointments", "reminders", "accounting", "currency_transactions", "offers", "offer_items",
    "personnel", "announcements", "contracts", "bank_accounts", "bank_cards", "loans",
    "checks_notes", "e_invoices", "projects", "project_units", "project_transactions",
    "loaner_devices", "loaner_transactions", "logistics", "external_warranty_tracking",
    "vehicle_maintenance_cards", "vehicle_maintenance_items", "customer_vehicles",
    "automotive_service_forms", "automotive_checklist_results", "automotive_damage_records",
    "device_brands", "knowledge_base", "kb_articles", "audit_logs", "settings", "exchange_rates",
    "internal_settings", "notifications", "scheduled_alerts", "quick_notes", "users", "tickets", "company_info", "photos", "logs",
}

# Compressed CREATE TABLE/INDEX baseline from the desktop database.  The web
# server may be pointed at a brand-new SQLite file (for example after an IIS
# deployment).  Authentication alone only needs ``users``; the application
# shell, however, immediately reads operational tables such as ``customers``.
# Keeping the complete idempotent desktop schema here makes first start and
# upgrades self-healing instead of depending on a pre-populated database file.
_OPERATIONAL_SCHEMA_B64 = "eNrtPUtz20aa5/WvQKVqi3IVJ+NkZw7JnGSZTmliyx6Jno1PqCbRJDvEy3jIpv/A/oO56pjr6JLT3CT/r/26gW40gH6BBGVN7fqQiECjn9/71WeXs9P5zJufPn81885fehdv5t7sl/Or+ZWHlsukjAsSr72TJ17nHwm884v57KfZpff28vz16eV77+fZe+/03fzN+cXZ5ez17GI+7X1V7FLszWe/zKfeH/7g/YRDkk29n0iAs17TJSrwOsl2TfOXqCgzNPVeI/TlZupdoeL+lv7xM8mQd734ttcFiuj8PVjhK8VUsp2PP5TkGoVY22hZZhmOl9UkvBezl6fvXs29yfzy/aTfGH9ablC8xn4GU2cdii+++/ZZv32SkTWJUegb5xngfJmRtCBJXG1FvwUdTv1qmWF4Gfio0DUo8yKJcOY352loFKNINxLJfRJfJ2SJG8Dgq1esPUW7CLbdj3CxSQJNnwsUb/0aCo0TzHBYLdOhbZolv+KluU2RoeUW4N6PE83UMrzSv8xxCCPAfHKcXcOO5Kxdq9mUziMoYR51G3k+vXcS2sA+B9B9odxmr37Fz/vpX56cmfC7INcYuqvmuCeOe9X3Emx4m4+kOlLv3cX5397Npl6I8sIPEwD3/lZYJhnHcKRLTKHlgDkKFIG9JYB4xU5zdgUpQt50mcQFpQ3VL1QCqGb8VRuxxBmcvbu8hBH9+fnr2dX89PXbIUtNUz9ECxyq1kn/bfGu2WZ5uVNl8wCvUBkWPlC4Uoe2DZFzaCdT5IYY/hQmCxROdHOwUS/6r0yDPXbTaUcTEhcHwc5e1DDdJDEeTq4Lou3RvpF5Afwx7xzOc7wNyS7JJoyD8l9Tb44iFIUoDu5vp979P9MChTbm0aVfOMuTOMYhxyv+W6YEFW2ofywyGK/+O0oC8SVQOQJckJNTr8zWgudSJAwF1jF45s/rY+j8bNNRMSf5qURN46SoqTNMIymzNq2tn1BaL38PJBhoQeLX+9OnwxagzHMCZwUIB6OTFQG0gkPdn7ZFOM/Rms+5mb6KRQMIFTBgqOIdSvgpY1hkMDFLFhw7x6GCZUAYrxgPY8u8got6h9AibLErygc5VgHEFoiEuZrMD1oGgGPCGOwCFQWm0iaVCjK6/T5AHaVIbgd8jTdkGbYlhJrptsC6K7SID9OwYX98MtdJWFCoaYmpAAUgwmZr2ouuAYBJBj34ErhMvY8oi+lHIVlvCv4wWQT+EvA8VyCbM/+cujMH5wNZbvByW6b+Kski51Po7bgQbvobryRGqmNUnVCBI/bTB3bPCVEZRUioQmz6IdAQ/9dcwG2Gl0kEjC6AnSLQRS6//Kq7HQCrAaUIFrDdf7NN4G3b0Bz0SxnfPwNvln9/6sH4rveEzr4N8hSaH8X2ghJ9TTH6cUIz/gTUPAngeyAaKrazKoE9h/ga/kvbcoKS0P1ugb1YqLTz9TPY0CLpPULFYzifCBGqRaCYyhYctRmGup5V81XTnI518e7VK5BG4LW/zpIy5RoifcD0CP4Axs9AuAdM3OWqIxANtpFaqaz0CB34v3xzOTv/6YJO/USa61NAopcz2LWzmXVD8hPa/s0FDPtqBnt6dnp1dvpidtAmO+9vo1I1uyrW0RcHG7LMdPFKJlXtKoiJTMPuvfzuK4NkChw8B7H2QwliyDBYFB+pQJH2KxPWD0WHkMLCEwDORtKPgTgsk7zo0VsNeDXD66CrtbZDward2ajM6yCimpdpGpKWCuq1sBN/SisLlGT44Hv3WBjXhxIm8ki5VjU30RdK0yyhBLK1yeKpzJBIXpkgJZtuS3ouF0UCynbvBXuq++oRnNMgKtEcrYFnyUZN+ttCOBitSDNqTuhuT3UQCk38O0G0XXhXa9Y6+iJB7YHEhRt3awxQGsb2RQu+1Rw/lJ3vjzPK7lR4xJ9dE66K4Bi0S8z0QoNBEMfUPWMSG21ypbJbWdakI3CzklIERcslTgsmUkiaq9oyqtLIZL2npYzxTeb0w3X22+vt1vRRv2eQhT7x5bCvm9/qdRyBzqhHkvFOgG8L52q3hBrJhtqBG6wrSAaoV+YpjnOSxD7Vm7NgbFuMUq9nI5PP/PcqS4BPhHhVgBSZFpseWasaZNSkomkBx5WZemDvTR2gkKxj5ohrEcgFChnctx7mm2QJ8LfIk2zRtf8sMrTF/gYwoPHYPhpzDz+Meno+IHp8mPVNSSf3Nsmx+cjsUPZBtXXgFO3CBAV72Xac9+sjyjIUFzt/iaIUAYA8BHbwseR9EM90Yi6zRcoyLo5bIi+lgjS44FFApOzNHs+2zXptGbMr+XOThM3CCbTqvI/LaMHf9zuF819uJCZtDIQwarrWkAThfqyJTo9GDfJ4D7DQs51bIkb89xe+lF9qAhcaCVjjX80Ck1NRtKHe9D9ZG5GI9DQJo/83wAu3D4KSWnV3ZnGQIirz2tubDoKfYXKKVfjoHFVLBGlh7CiCCBMU81qeHBvq2sFVd/+Dt1PvCse4UB8iiCOy44vGY5GMfLnxTk7D+9sYxU+n0Mn97ZZGWXknf8cZCXH8VNlZmmTFKglJog+KsQZkNZBVmDCA5HkpCBtM+mf85QZo/JJ4f/SeJ9ndb2Gp/A5WS1LShHPAp3Sdy/tb7+Q5+QxMaYfgxL/cbFF+f/tUj9cWDK1pp6WVIMOJTa0wN3GLr1C6dt/SM7v7fRfgKjig+U3DAzY5Cb1ZQMKATL0zkiXix90/AmCz8MfPKPtyc38Lm7iFHftM4whQgNWHxlShFIEIOoL2MRTpEhAj4p1P4lUyXhRI3anCeNyPQ2SRQyD5B34VkbBH1AiOEAk171AQZDjXKagF+uQnq5WIw1A2MIoDYbJOTIc3LBZA4Z+XBKxRYwloABeI4McI/mmJ+bK8bhZJFXBUTVGWe9VWLiUSn24Lspo4hAsdJWKNS4U+LCHOqziK8fmaU4xqbdDis/ANcTBOnKgl8GqMVL14X920HCKN3Ym5PTjVKfJXlvzUove3z7Ti2pBQ347E5Z1I59kSt/hzJmoNpfHC9NXosfhTURl5HgIi3UyuCs3X2E7YTY2tpMA6Yzsp6M7YbodR5tCsMuWOYk48LCrULuU7gdzh0j0fRdDFGrHyB4VAB4JmaatRxZVtWWh3fVQGWBhOAdT9VNgl99AYJ/YmGjp9bDwZwZIJM7mAGYAYPvnvDSry0zSlf1+9vqL/O0NhOFHKDUKZGZ73MRg5nuyxrSL94UF3tp9QYQJh3tqgr30oUVzQjAEH64TeS9mHAIPHt9fY5IFyzP8ZV7LmJ1Hg5SZmMa18Jx8h261t0BaZsG5l46Z1Mxsz/T/L/Grx4DHwvEbMcoMTXYZCIxAJ4ccCS7WbW6LyzMksxzzEeVoZ4HwXq1fTmmYNLOUPui9XxCb3fwC8TbaYq4aMhW/j5GM82KMuu1Qe2ox7rKwhgRej8a09M4VMNp+2/PCcZHiX43Dq/VxmZZQrsnmolYcEJhNQspd5yZIlRJf3vUjl6djMpl6xbHyjXTtUz3JFo6toAoXwHIk0Pi/GZL1ZJNkm4dmkHjTFmDf9TFLZnSWDLUB7pA2NZV4UbTBXlIMSRNNJlKFHgA9plsDbCAHGKnuHF0UZ9G09YQL0Q/lGkRJKA/9JXkUz9DKPn42aMiqzyPEJvBubtvHn45GhgXSEL6eKHR0rg95q/SlYkKee4gAuN1l0LAv/7reCmfNDlg04h++ZsT/C1MrP/CJ3v4d3v939K4I13d/gjCjlU+18mIRIUGyasGBnT4Zu8PH2VisruKSAOkiTDpJkJzey976KzG/XSugrJXJCpSlvVMGCWCCeQTiBsyMRaocaK3LuXRQiO/qTCBPdECyvLfbDZLm11TowjNC0MbHLxtADWjhaFsbDsVt1gUkWRgdLvTMpyvOPSaablSpKuZ0JjCM86TBopUMjRMBK1YH5GU4Ryfx2mmQXxT0RQtQJyBHPlVN8n2wnnQT95uVFkkU0zbzKVonrsGsRzgNz1UQHN8GZrdiho8Q60tCLdeKvcH8aIn1J4tw0xDTPYbVNEnLN3jO84s4gARyynJ0tN+Ray9C7CVBuobnCTCwl07BQEhk0+ASruGo5L7uV60lzP1u6QaOitCPaBNDW6QnytMU76t5n8o14VTsgfJqdvGse87IiJgxg/m4WPiyrUOPJSJh7R0ZMYC67BTUo3z5/7s3m84v+GPXeCEBrtuDqdH5+NVHJBEtMgcYsN9Rtrrc6Qmb0qinP5MXl6ct5FX/A/px6sLx3sxdT74pFFJ6+fXv55u/09+Xsr7OzOf3r5en5q9mLPhUNViYaSkMm6YmjRvJ5D7Cw9ZIQZWjrre9+j4MqxsX769Wbi38fL3fLD3kMs8sAx0G5o/KTxSEKimro0AyvVrguUWM2jki0SApNPHv9fOIk8A8U66l9k/Efwcy43DgavgsW1w8gBrB9ffevLzfQgHizCMWg4l4k+xUpqasMGZqItfbN5IwESThzRVvkf3yvKOXV74WvxqO9VF+C/rG7v4XFlMAdaAiWQhaOCxMoJGWxAPoT+BUT1srMJHZq1pIW2v/EpLH3LkRwGFRvehOj7P42CtBUWYzMZMHfv8zECtUZfSM6WczKhJxZ/OQg3TsgOQgkOx8kWpXBccAuCHzJcUHr1ak2g6ftmusmNTWQBgz/K6KwYC3ncjgppv9a5V60rSw2FHs5GO1nw8rEjOCIcjuD7QKE4kLneHBMtNfW/irQ+vCSMCGQvjjHB8UhgkK+zHYpnUCTh847Nhx6PyztU0pamn3lBahCTqWnopYbT1GtB8sPQtgwQVSYB915oyvOdRimsAGc/UQrIlcEcmksBE2XxhZktGUXlinL+akOZR/Jsxd/Ue9OyxtIn43jCax6jwHkwvAxnK40Fcrt3T5q+eQsbfuefItbMiPxkqTwDS0w4PIFY3DUTOr6wXYL2pDSbaGL6lvk0fWwLywF59RLRySwifMDLDOD1Ha7p/z4eIEzQ73NB/OeSCZnCxzV9ucILQe40dWaPk6TAOnKRCIS7vwUgwwH+pTCfKYeZ4PDlTkM1pq5fSTfT33WR42L1qf9W+InXDmd+MDkpB4QkpzEAWEmQNDUnNoZo18pFfHXoGvEe0UPiBIpGS7KzDpQ1coY4sjBF7HiLIEbCA8J6h839c3TJN63ydRolO/BsiyrgAh0fxPe33pJGJT3NyVri7wNztFCYVlQ5HZVndCPUEBTxHbMVrgg4Zo83S+jQPBwW7oAjUeIQP3Y5NYMy6ywMdNKNqnt4gfnHpjAlWXU0T+n3nNSRISWZtdUlj2M8k4r+U9h3p6jbQ46HJnwJpJCxyQiZXwEk3yOHTlBi1/noJ8eIe3Tjfg6GASt3uDKPMQ8XCSLTFBnibQcSQAcTIbWDxmIAcOZpDGzIYfWrB3dWuhioTrAUdC7sWHykjA3IotmL5Ilde9O5jximD3d5QWOJmogarBXJycYQuDZCRCg6cJ+AROitZZooEDAXnn42/W33jc5ndmP333/X99MvW8o3fjxT3+mf3KU+fGHH75xp4bcFMbWL35M+P+553ai0wxVvu+Y+75pn+LHZEPWG/p/bsabWLFpX+sBnX2rg4GYl6xWNMSgqiE2MtjVfTtbA2itMVsmYadAmU41utYn1brzVFs8m6IYmtpM5J56UOMGKIuqWnQaxb1becaqTfODaUmX7OE4UmXV1ZHgyRYC5pyOMoT59gNktYQPmR13tX+P3XRiaaYodWr0A9tqt4l2+S5aJOGgBFobjOvKJ2oqXFS1GJ0aX6NCKQNqGzsm7ggZ3E0drNfn0+J0Q9bo/EEzdedPhs1IyRSDDK2KidV7r4Fjc2DHAOr0SBMOWJnZB0k2aBfoVXiJaPSk4eokzlwU7+AQNyjHjhxo0MVaBoKzAHlK/1Z3Yw2OcdgNhIxI7LfWL9r/eaoop1DbHuV0hW4YJ6t1LCUdNDUAWpW1KM0vyILnZ+dOEWm9KlqNFGGBNXFtywPAG1ViGmOjjpVawlqzJNwneSZHIXIgWU3yRE/7pzVxMhJ5CWwtNQH959PhebbGsi2aSIn/6ECmnCMTYIrDkeSZBhhZZyjiao7l9CmIfi0ThDXMuWkkBZnomMxaTp+uKldNqmSFyf0/v9yEOq3yWMYFHk3F7IgRSlNNHMphO91WTIapOtakf8fb9irVpor53QYq09n3z8xfWUKMxmfVxloCYk+nfMeeDj97Jmkf1d3jcnFh2/ZmvWNTbbV5jcLPOMLUevvl5u43EpKtdNvmHH25wRmQS1oHLMI5sVnDHTTL3lWQdBoXaEuKaWWEn7JydvvYEg+wa7NCZzQJqjK8iJ+iBNreHm56oxi7hqpZLT9dqsXnrE48rwyVZLm2E6vi6e5KV95G2jw1FgAdevNp11LQgHbLVlA/HsdaIG+wXxPr8ZGU9e6en95DadsHVIC3HXpbynfp0aLRDymA4eJ0R0EwTmWDerdVQFMhkhpyHiFAgrSKvx7L6ECtNrbfbsGqGhVLaxNbSEHVyiQ+N63MCeoVF6iTr2yZBPQY/AynB4SUsFQzdzssHXJA84BWaeAs09lg1fpqAG/O6AGwm/2GlITiA6UhMsZVJMuyig88mhh4ME4fjQYdQCy+Hp1Y0OxaGwlYhUmSmTVBtmfGFkqBjMmgtNxsJZCJn1PvEn/G2TWuxVSRxx6C9l6VrdV52xwhmk3YVlISQNUQYNFxzxijNSytlDm7YkNg8bsceVt6l3DOnxwgGw+QIUGYoHjfZSfV2rekNlBJMYGIZHjyqNjx+MjlKok5hfNYqslWPDFY42J/W/0LfI0Y2ohro+UnbldHHwG6FGFAygR1hTop1bymxcLjiSbtXeGmY1qWsL5ZMq8P0ZGaQsDCQGaG1w8lYcXBx0z9YtdImui7yS437BYIZ8u8eRcyTMOqMhbRsndOzaoMW7eWm6RORQ0jSZSlbpA0yaWscpA6WUEulxSrgsVa91J15DXuVScFpDhC8zQfMvjJHN1kqXhGcpbY77Jn5vJTcgBg98J6aYcV7h19oKN5r/PlBgdlSGcU4uwI7IR162wCBpBar6lGRtyYEDFVtNJ9MTSNkGWa1TMzRlQfKP3X9t1mx4badXNMzW8gj+EcH+Eo6+4t8vQW7+yRHnSCfpO8atwPadip6H341lSp3A9Sb3vPCw7HrbbNi6VvI3tQmDWW5tEUBz3+5Xt8SwK8IjE5jm+kV57AetWS1QE1wCRT1vLHoV6IY7km+e6MGv/M080GhkEzd+1ZLWhPvCQTAcEExdVvXUywWaSwuuJFRPWT4Tv3kFWO9yR2bul/tnpy9J+qSNf/k7HRi5k7BMaMH0plJ0RWPDIGJikG1N/PN22Fb9m2n1f2UBbykAp3WPqJckoHj6cJtdTBFsnyio+EXpGWi4wEVtFmeBoHC1N7GMmr43B0I0XtuDe1HUsVC6ePie7Hxz1yelTvW9tcScM8x6FFDACi5Bofp76Ck5uZDz/gqiVrNXH8sY7BdJK79hGqtErsAJpmo2sOB9gK7/hq/hxXcfnXZNER4WYh3oIGTwOD7m+v0dR7nuyQsu5V49YQFs4BEMFTHVjNnMfrJhx4/AVZbvH+Id9q6zXAFJ2htoSsk4nrzdvZhaEG65vL16evJg6X+nZI6QDmBmJ64Osi4h8kTHV4jI1NgxwnrKYdYu/nMUrzTTLkjl9HIdFmV61ktxGTo6lqNmK11DGizk0+AENEupXbWIr1P1HaSmnyeKwtyxphmoQg3+ihuoE0qXsxl+1iZvJ6gnnXcN4iN12nSY5h7YXPivhKRKZ6iuL8o8iT0HqJqhIJK0TV64Beu8DKI/dnbAYmXRnj8emJ6rr7Q3IC3QuumAo6y5fY7H/zn+Kim/6lNur4j8d70c3Q222E6bKZQgy6Vgu0LOuJUFzSoNo0TeCbqF3C1FM/VovRUtPGmyMo+bMffnz2bDK1RqdxX2CrKju9dA7692V9VCP20kS+1mpadeNJvKU3AbiaBqtwOfmbFirVtHSx+7dQ+RpqoLxlS9yLtcftpiqSdpxk+k6990Yv2CPzpAkWkLoBZkKLMAzwL1KewIrAq67o+eHZtGmxjZyvraJY3KZGzbOhVGIb+WoMsiJj65a2audbsKNlZaNoIarej5QgpgerTlKYLVq9mx02pub38CfwES8AYmphq73nw/eaMTofFISNQ6k+KiPb0w66m6tuxUrJ4tzSigmyOcaxpR2XZ23Yx1aA1uoCMCQ1BIW3onfzfokKpo1Yztdyrpwc8NoKcLpumr0sDErlbZrhzi9ezH7plr8OPvHEPcpuOceh028et66BHNIdI5HtruijQX1QvqHqqMq6c+yuETpy1hf3T9EupXdsdty84dBtY0ZfsDuEdj6orkt6zxytekAv7/IlPKCD2b84ab4YNANWfrlMfcoiDcO2mu07VoAiQB+gbNnWMJTcau+RePaFZVntdvuOJpNqgX/6QZXN9x2b2a34VTaGQdvt9h3tQwnyhW1TpUb7jlMAeffzEnSvuDJc4GUCLFA/puaDfcfnTHhDgIJRbLtmNEA7vLr9vqMLd/gSRSki69gwcr/toFHFzaPcslYZB2AM6a5e8bLiFkN67ffm1kPtR6/jeyW6yx3s1RPZJtgKlnYfQeZdvPNBjKvbkVhzr7dhSw8YF5f6aW7Gk4XQAR3WxE7uU766S7qjyr1T3cm49yDuspH6kBR5e0dy4XeqTtGOehXhT7juNbA/2pG6Q166e1h/zX71e3TduXa93E6XUiHdgf0VnySbSNObXGJAinoZ0Gtvgq0uXWdZFV/rUMK6uNsQdOD9SGZTqSMV5lfqjLbDxlot/ADQoXh6wp/apyaHzTXGLC7Fym9P+havYUShcXq1ELB5PAwHFd2Jeav7HDZdWW/1q5tEaNfy45NGKxzYH4vT6/bG9bS//C+Rw8dC"


def ensure_packaged_source() -> None:
    """Always prefer the self-contained desktop engine shipped with this web project."""
    root_text = str(ROOT)
    while root_text in sys.path:
        sys.path.remove(root_text)
    sys.path.insert(0, root_text)


def runtime_status() -> dict:
    ensure_packaged_source()
    tesseract_path = shutil.which(os.environ.get("TESSERACT_CMD", "tesseract")) or ""
    status = {
        "python": sys.version.split()[0],
        "database": str(active_db_path()),
        "packaged_source": (ROOT / "src" / "utils" / "pdf_manager.py").exists(),
        "tesseract": tesseract_path,
        "ocr_backends": {
            "tesseract": bool(tesseract_path),
            "easyocr": importlib.util.find_spec("easyocr") is not None,
            "paddleocr": importlib.util.find_spec("paddleocr") is not None,
        },
    }
    try:
        import reportlab
        import pypdf
        status.update({"pdf": True, "reportlab": getattr(reportlab, "Version", ""), "pypdf": getattr(pypdf, "__version__", "")})
    except Exception as error:
        status.update({"pdf": False, "pdf_error": str(error)})
    try:
        import PIL
        import pandas
        import pdfplumber
        status.update({"smart_import": True, "pillow": getattr(PIL, "__version__", ""), "pandas": pandas.__version__, "pdfplumber": pdfplumber.__version__})
    except Exception as error:
        status.update({"smart_import": False, "smart_import_error": str(error)})
    return status


def parse_xlsx(payload: bytes) -> list[dict]:
    """Read the first XLSX worksheet with only the standard library."""
    with zipfile.ZipFile(io.BytesIO(payload)) as book:
        shared = []
        if "xl/sharedStrings.xml" in book.namelist():
            root = ElementTree.fromstring(book.read("xl/sharedStrings.xml"))
            shared = ["".join(node.itertext()) for node in root]
        sheet_name = next(name for name in book.namelist() if name.startswith("xl/worksheets/sheet") and name.endswith(".xml"))
        root = ElementTree.fromstring(book.read(sheet_name))
        matrix = []
        for row in root.iter():
            if not row.tag.endswith("}row"):
                continue
            values = {}
            for cell in row:
                if not cell.tag.endswith("}c"):
                    continue
                ref = cell.attrib.get("r", "A1")
                col = 0
                for char in re.match(r"[A-Z]+", ref).group(0):
                    col = col * 26 + ord(char) - 64
                value_node = next((item for item in cell.iter() if item.tag.endswith("}v")), None)
                inline = next((item for item in cell.iter() if item.tag.endswith("}t")), None)
                value = value_node.text if value_node is not None else (inline.text if inline is not None else "")
                if cell.attrib.get("t") == "s" and value:
                    value = shared[int(value)]
                values[col - 1] = value or ""
            matrix.append([values.get(i, "") for i in range(max(values, default=-1) + 1)])
    if not matrix:
        return []
    headers = [str(value).strip() or f"kolon_{index + 1}" for index, value in enumerate(matrix[0])]
    return [dict(zip(headers, row + [""] * (len(headers) - len(row)))) for row in matrix[1:] if any(str(v).strip() for v in row)]


def smart_import(filename: str, payload: bytes) -> dict:
    suffix = Path(filename).suffix.lower()
    if suffix in {".xlsx", ".xls", ".csv", ".pdf", ".xml", ".docx", ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".ppm"}:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as source:
            source.write(payload)
            source_path = source.name
        try:
            ensure_packaged_source()
            from src.utils.stock_import_parser import StockImportParser
            parsed = StockImportParser.parse_file(source_path)
            if suffix in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".ppm"} and not parsed.get("rows"):
                try:
                    from PIL import Image
                    with Image.open(source_path) as image:
                        parsed["text"] = StockImportParser._ocr_image_to_text(image)
                except Exception:
                    parsed.setdefault("text", "")
            parsed["engine"] = (parsed.get("metadata") or {}).get("import_engine") or "AYEC Pro StockImportParser"
            parsed["original_name"] = filename
            if parsed.get("rows") or suffix not in {".csv", ".xlsx"}:
                return parsed
            parser_message = "; ".join(filter(None, parsed.get("warnings") or [])) or "Masaüstü ayrıştırıcısı satır üretmedi; standart okuyucu devreye alındı."
        except Exception as parser_error:
            parser_message = str(parser_error)
        finally:
            Path(source_path).unlink(missing_ok=True)
    else:
        parser_message = ""
    if suffix == ".xlsx":
        return {"engine": "XLSX standart kitaplık okuyucusu", "rows": parse_xlsx(payload), "text": "", "warnings": [parser_message] if parser_message else []}
    if suffix in {".csv", ".txt", ".json"}:
        text = payload.decode("utf-8-sig", errors="replace")
        if suffix == ".json":
            data = json.loads(text)
            rows_data = data if isinstance(data, list) else data.get("stock", []) if isinstance(data, dict) else []
            return {"engine": "JSON", "rows": rows_data, "text": text, "warnings": []}
        try:
            dialect = csv.Sniffer().sniff(text[:4096], delimiters=";,\t|")
            reader = csv.DictReader(io.StringIO(text), dialect=dialect)
        except csv.Error:
            # A one-column/export-without-sample CSV cannot be sniffed.  The
            # desktop importer falls back to semicolon in that case.
            reader = csv.DictReader(io.StringIO(text), delimiter=";")
        return {"engine": "CSV akıllı eşleştirme", "rows": list(reader), "text": text, "warnings": [parser_message] if parser_message else []}
    if suffix in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}:
        configured_tesseract = os.environ.get("TESSERACT_CMD", "tesseract")
        executable_text = shutil.which(configured_tesseract)
        executable = Path(executable_text) if executable_text else next((p for p in (Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"), Path(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe")) if p.exists()), None)
        if not executable:
            raise RuntimeError("Tesseract OCR bulunamadı")
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as source:
            source.write(payload)
            source_path = source.name
        try:
            result = subprocess.run([str(executable), source_path, "stdout", "-l", "tur+eng", "--psm", "6"], capture_output=True, timeout=120)
            text = result.stdout.decode("utf-8", errors="replace").strip()
            if not text:
                raise RuntimeError(result.stderr.decode("utf-8", errors="replace") or "OCR metin bulamadı")
            return {"engine": "Tesseract OCR (tur+eng)", "rows": [], "text": text, "warnings": [parser_message] if parser_message else []}
        finally:
            Path(source_path).unlink(missing_ok=True)
    raise ValueError("Desteklenmeyen akıllı içe aktarma dosyası")


REQUIRED_OPERATIONAL_TABLES = {
    "customers", "customer_currency_balances", "devices", "used_parts", "parts",
    "stock_movements", "accounting", "appointments", "scheduled_alerts", "personnel",
    "offers", "offer_items", "settings", "internal_settings",
}
REQUIRED_WEB_TABLES = {"users", "company_info", "web_sessions"}


def operational_schema_ready(conn: sqlite3.Connection) -> bool:
    available = {
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }
    return REQUIRED_OPERATIONAL_TABLES.issubset(available)


def schema_ready(conn: sqlite3.Connection) -> bool:
    available = {
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }
    return operational_schema_ready(conn) and REQUIRED_WEB_TABLES.issubset(available)


def ensure_operational_schema(conn: sqlite3.Connection) -> None:
    """Create any desktop operational tables missing from a web deployment."""
    schema = zlib.decompress(base64.b64decode(_OPERATIONAL_SCHEMA_B64)).decode("utf-8")
    conn.execute("PRAGMA foreign_keys=OFF")
    try:
        conn.executescript(schema)
        conn.commit()
    finally:
        conn.execute("PRAGMA foreign_keys=ON")
    available = {
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }
    missing = sorted(REQUIRED_OPERATIONAL_TABLES - available)
    if missing:
        raise RuntimeError(f"Operasyon veritabanı şeması oluşturulamadı: {', '.join(missing)}")


def ensure_web_schema(conn: sqlite3.Connection) -> None:
    """Add the web authentication schema without changing desktop data."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            email TEXT,
            role TEXT DEFAULT 'User',
            created_at TEXT,
            last_login TEXT,
            remember_token TEXT,
            auto_login INTEGER DEFAULT 0,
            permissions TEXT,
            full_name TEXT,
            active INTEGER DEFAULT 1,
            interface_edit_access INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS internal_settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS company_info (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_name TEXT NOT NULL,
            authorized_person TEXT,
            phone TEXT,
            email TEXT,
            address TEXT,
            tax_office TEXT,
            tax_number TEXT,
            logo_path TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS web_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token_hash TEXT NOT NULL UNIQUE,
            user_id INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            remember INTEGER DEFAULT 0,
            user_agent TEXT,
            ip_address TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_web_sessions_user ON web_sessions(user_id);
        CREATE INDEX IF NOT EXISTS idx_web_sessions_expiry ON web_sessions(expires_at);
        CREATE TABLE IF NOT EXISTS sync_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_id TEXT NOT NULL,
            table_name TEXT NOT NULL,
            record_id TEXT,
            action TEXT NOT NULL,
            payload_hash TEXT,
            created_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_sync_events_source
            ON sync_events(source_id, table_name, COALESCE(record_id, ''), action);
        """
    )
    user_columns = {row[1] for row in conn.execute('PRAGMA table_info("users")')}
    additions = {
        "email": "TEXT",
        "role": "TEXT DEFAULT 'User'",
        "created_at": "TEXT",
        "last_login": "TEXT",
        "remember_token": "TEXT",
        "auto_login": "INTEGER DEFAULT 0",
        "permissions": "TEXT",
        "full_name": "TEXT",
        "active": "INTEGER DEFAULT 1",
        "interface_edit_access": "INTEGER DEFAULT 0",
    }
    for column, definition in additions.items():
        if column not in user_columns:
            conn.execute(f'ALTER TABLE users ADD COLUMN "{column}" {definition}')
    conn.commit()


def _raw_connect(path: Path) -> sqlite3.Connection:
    path = Path(path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def _ensure_path_schema(conn: sqlite3.Connection, path: Path) -> None:
    current_path = str(Path(path).resolve())
    if current_path not in _SCHEMA_READY_PATHS or not schema_ready(conn):
        with _SCHEMA_LOCK:
            if current_path not in _SCHEMA_READY_PATHS or not schema_ready(conn):
                ensure_operational_schema(conn)
                ensure_web_schema(conn)
                _SCHEMA_READY_PATHS.add(current_path)


def _tenant_filename(company_name: str) -> str:
    """Return a safe, human-readable Windows filename for a company DB."""
    value = unicodedata.normalize("NFKC", str(company_name or "")).strip()
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "-", value)
    value = re.sub(r"\s+", " ", value).strip(" .") or "AYEC Pro"
    return f"{value}.db"


def _legacy_company_name(conn: sqlite3.Connection) -> str:
    row = conn.execute("SELECT company_name FROM company_info ORDER BY id LIMIT 1").fetchone()
    if row and str(row[0] or "").strip():
        return str(row[0]).strip()
    row = conn.execute("SELECT value FROM settings WHERE key='company_name'").fetchone()
    return str(row[0]).strip() if row and str(row[0] or "").strip() else "AYEC Pro"


def _legacy_has_data(conn: sqlite3.Connection) -> bool:
    for table in ("users", "company_info", "customers", "parts", "devices", "accounting"):
        try:
            if int(conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0] or 0):
                return True
        except sqlite3.Error:
            continue
    return False


def _new_tenant_id(company_name: str) -> str:
    ascii_name = unicodedata.normalize("NFKD", str(company_name or "AYEC Pro")).encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^A-Za-z0-9]+", "-", ascii_name).strip("-").lower() or "firma"
    return f"{slug}-{secrets.token_hex(5)}"


def _tenant_row(conn: sqlite3.Connection, tenant_id: str):
    return conn.execute(
        "SELECT id,company_name,db_filename,created_at,active FROM tenants WHERE id=? AND COALESCE(active,1)=1",
        (str(tenant_id or ""),),
    ).fetchone()


def registry_connect() -> sqlite3.Connection:
    """Open the central registry and lazily migrate the old single DB."""
    conn = _raw_connect(DB_PATH)
    _ensure_path_schema(conn, DB_PATH)
    has_registry = bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='tenants'").fetchone())
    if not has_registry:
        # Copy before creating registry metadata so the legacy file remains a
        # usable backup and all existing rows are preserved byte-for-byte.
        company_name = _legacy_company_name(conn)
        if _legacy_has_data(conn):
            TENANT_ROOT.mkdir(parents=True, exist_ok=True)
            filename = _tenant_filename(company_name)
            target = TENANT_ROOT / filename
            suffix = 2
            while target.exists() and target.resolve() != DB_PATH.resolve():
                target = TENANT_ROOT / f"{Path(filename).stem} ({suffix}).db"
                suffix += 1
            if target.resolve() != DB_PATH.resolve():
                with closing(sqlite3.connect(target, timeout=30)) as destination:
                    conn.backup(destination)
                    destination.commit()
                tenant_id = _new_tenant_id(company_name)
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS tenants (id TEXT PRIMARY KEY, company_name TEXT NOT NULL, db_filename TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL, active INTEGER DEFAULT 1)"
                )
                conn.execute(
                    "INSERT INTO tenants(id,company_name,db_filename,created_at,active) VALUES (?,?,?,?,1)",
                    (tenant_id, company_name, target.name, utc_now().isoformat(timespec="seconds"),),
                )
                conn.commit()
                has_registry = True
    if not has_registry:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS tenants (id TEXT PRIMARY KEY, company_name TEXT NOT NULL, db_filename TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL, active INTEGER DEFAULT 1)"
        )
        conn.commit()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS control_admins (
            tenant_id TEXT NOT NULL,
            user_id INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (tenant_id, user_id)
        )
        """
    )
    conn.commit()
    return conn


def tenant_records() -> list[dict]:
    with closing(registry_connect()) as conn:
        return [dict(row) for row in conn.execute("SELECT id,company_name,db_filename,created_at,active FROM tenants WHERE COALESCE(active,1)=1 ORDER BY id")]


def tenant_by_id(tenant_id: str) -> dict | None:
    with closing(registry_connect()) as conn:
        row = _tenant_row(conn, tenant_id)
        return dict(row) if row else None


def _tenant_path(tenant: dict) -> Path:
    filename = Path(str(tenant.get("db_filename") or "")).name
    if not filename.lower().endswith(".db"):
        raise ValueError("Invalid tenant database path")
    return (TENANT_ROOT / filename).resolve()


def ensure_control_owner() -> None:
    """Assign the oldest tenant's first admin as the platform owner once."""
    with closing(registry_connect()) as registry:
        if scalar(registry, "SELECT COUNT(*) FROM control_admins", default=0):
            return
        candidates = rows(
            registry,
            "SELECT * FROM tenants WHERE COALESCE(active,1)=1 ORDER BY created_at,id",
        )
        for tenant in candidates:
            path = _tenant_path(tenant)
            if not path.exists():
                continue
            with closing(_raw_connect(path)) as tenant_conn:
                _ensure_path_schema(tenant_conn, path)
                owner = tenant_conn.execute(
                    "SELECT id FROM users WHERE COALESCE(active,1)=1 "
                    "ORDER BY CASE WHEN lower(COALESCE(role,'')) IN "
                    "('admin','administrator','superadmin','yonetici') "
                    "THEN 0 ELSE 1 END, id LIMIT 1"
                ).fetchone()
            if owner:
                registry.execute(
                    "INSERT OR IGNORE INTO control_admins(tenant_id,user_id,created_at) VALUES (?,?,?)",
                    (tenant["id"], int(owner[0]), utc_now().isoformat(timespec="seconds")),
                )
                registry.commit()
                return


def is_control_admin(user: dict | sqlite3.Row | None) -> bool:
    if not user:
        return False
    item = dict(user)
    tenant_id = str(item.get("_tenant_id") or active_tenant_id() or "")
    user_id = int(item.get("id") or 0)
    if not tenant_id or not user_id:
        return False
    ensure_control_owner()
    with closing(registry_connect()) as conn:
        return bool(
            conn.execute(
                "SELECT 1 FROM control_admins WHERE tenant_id=? AND user_id=?",
                (tenant_id, user_id),
            ).fetchone()
        )


def can_access_control_center(user: dict | sqlite3.Row | None) -> bool:
    if not user:
        return False
    item = dict(user)
    return is_control_admin(item) or role_is_admin(item.get("role"))


def can_manage_tenant(user: dict | sqlite3.Row | None, tenant_id: str) -> bool:
    if not user:
        return False
    item = dict(user)
    if is_control_admin(item):
        return True
    actor_tenant_id = str(item.get("_tenant_id") or active_tenant_id() or "")
    return role_is_admin(item.get("role")) and actor_tenant_id == str(tenant_id or "")


def control_overview(user: dict) -> dict:
    if not can_access_control_center(user):
        raise PermissionError("Management permission is required")
    platform_scope = is_control_admin(user)
    actor_tenant_id = str(dict(user).get("_tenant_id") or active_tenant_id() or "")
    result = []
    with closing(registry_connect()) as registry:
        if platform_scope:
            tenants = rows(registry, "SELECT * FROM tenants ORDER BY created_at,id")
        else:
            tenants = rows(
                registry,
                "SELECT * FROM tenants WHERE id=? ORDER BY created_at,id",
                (actor_tenant_id,),
            )
    for tenant in tenants:
        path = _tenant_path(tenant)
        sector = "teknik_servis"
        tenant_users = []
        if path.exists():
            with closing(_raw_connect(path)) as conn:
                _ensure_path_schema(conn, path)
                sector = str(
                    scalar(
                        conn,
                        "SELECT value FROM internal_settings WHERE key='current_sector'",
                        default="teknik_servis",
                    )
                    or "teknik_servis"
                )
                tenant_users = rows(
                    conn,
                    "SELECT id,username,full_name,email,role,active,last_login,created_at "
                    "FROM users ORDER BY id",
                )
        if sector not in {"teknik_servis", "otomotiv"}:
            sector = "teknik_servis"
        result.append({**tenant, "sector": sector, "users": tenant_users})
    return {"ok": True, "scope": "platform" if platform_scope else "tenant", "tenants": result}


def control_update_tenant(user: dict, data: dict) -> dict:
    tenant_id = str(data.get("tenant_id") or "").strip()
    if not can_manage_tenant(user, tenant_id):
        raise PermissionError("Company management permission is required")
    sector = str(data.get("sector") or "").strip()
    if sector not in {"teknik_servis", "otomotiv"}:
        raise ValueError("Invalid sector")
    with closing(registry_connect()) as registry:
        row = registry.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
        if not row:
            raise LookupError("Company was not found")
        tenant = dict(row)
        active = 1 if str(data.get("active", tenant.get("active", 1))) in {"1", "true", "True"} else 0
        company_name = str(data.get("company_name") or tenant["company_name"]).strip()
        if len(company_name) < 2:
            raise ValueError("Company name is required")
        registry.execute(
            "UPDATE tenants SET company_name=?,active=? WHERE id=?",
            (company_name, active, tenant_id),
        )
        registry.commit()
    path = _tenant_path(tenant)
    with closing(_raw_connect(path)) as conn:
        _ensure_path_schema(conn, path)
        upsert_setting(conn, "internal_settings", "current_sector", sector)
        upsert_setting(conn, "settings", "company_name", company_name)
        conn.execute("UPDATE company_info SET company_name=?,updated_at=CURRENT_TIMESTAMP", (company_name,))
        conn.commit()
    return {"ok": True, "tenant_id": tenant_id, "sector": sector, "active": active}


def control_update_user(actor: dict, data: dict) -> dict:
    tenant_id = str(data.get("tenant_id") or "").strip()
    if not can_manage_tenant(actor, tenant_id):
        raise PermissionError("User management permission is required")
    user_id = int(data.get("user_id") or 0)
    with closing(registry_connect()) as registry:
        row = registry.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
        if not row:
            raise LookupError("Company was not found")
        tenant = dict(row)
    path = _tenant_path(tenant)
    with closing(_raw_connect(path)) as conn:
        _ensure_path_schema(conn, path)
        existing = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not existing:
            raise LookupError("User was not found")
        updates = {
            "username": str(data.get("username") or existing["username"] or "").strip(),
            "full_name": str(data.get("full_name") or existing["full_name"] or "").strip(),
            "email": str(data.get("email") or existing["email"] or "").strip().lower(),
            "role": str(data.get("role") or existing["role"] or "User").strip(),
            "active": 1 if str(data.get("active", existing["active"])) in {"1", "true", "True"} else 0,
        }
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", updates["username"]):
            raise ValueError("Username format is invalid")
        password = str(data.get("password") or "")
        if password:
            if len(password) < 8 or not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
                raise ValueError("Password must contain at least 8 characters, one letter and one number")
            updates["password"] = password_hash(password)
        setters = ",".join(f'"{key}"=?' for key in updates)
        conn.execute(f"UPDATE users SET {setters} WHERE id=?", (*updates.values(), user_id))
        if password or not updates["active"]:
            conn.execute("DELETE FROM web_sessions WHERE user_id=?", (user_id,))
        conn.commit()
    return {"ok": True, "tenant_id": tenant_id, "user_id": user_id}


def clear_tenant_context() -> None:
    for name in ("tenant_id", "db_path", "company_name"):
        if hasattr(_TENANT_LOCAL, name):
            delattr(_TENANT_LOCAL, name)


def set_tenant_context(tenant: dict | None) -> None:
    clear_tenant_context()
    if not tenant:
        return
    filename = Path(str(tenant.get("db_filename") or "")).name
    if not filename.lower().endswith(".db"):
        return
    _TENANT_LOCAL.tenant_id = str(tenant.get("id") or "")
    _TENANT_LOCAL.company_name = str(tenant.get("company_name") or "")
    _TENANT_LOCAL.db_path = (TENANT_ROOT / filename).resolve()


def active_db_path() -> Path:
    return Path(getattr(_TENANT_LOCAL, "db_path", None) or DB_PATH).resolve()


def active_tenant_id() -> str:
    return str(getattr(_TENANT_LOCAL, "tenant_id", "") or "")


def active_company_name() -> str:
    return str(getattr(_TENANT_LOCAL, "company_name", "") or "")


def create_tenant(company_name: str) -> dict:
    company_name = str(company_name or "").strip() or "AYEC Pro"
    with closing(registry_connect()) as conn:
        filename = _tenant_filename(company_name)
        target = TENANT_ROOT / filename
        suffix = 2
        while target.exists():
            target = TENANT_ROOT / f"{Path(filename).stem} ({suffix}).db"
            suffix += 1
        tenant = {
            "id": _new_tenant_id(company_name),
            "company_name": company_name,
            "db_filename": target.name,
            "created_at": utc_now().isoformat(timespec="seconds"),
            "active": 1,
        }
        conn.execute(
            "INSERT INTO tenants(id,company_name,db_filename,created_at,active) VALUES (?,?,?,?,1)",
            (tenant["id"], tenant["company_name"], tenant["db_filename"], tenant["created_at"]),
        )
        conn.commit()
    with closing(_raw_connect(target)) as tenant_conn:
        _ensure_path_schema(tenant_conn, target)
        tenant_conn.commit()
    return tenant


def db_connect() -> sqlite3.Connection:
    path = active_db_path()
    conn = _raw_connect(path)
    _ensure_path_schema(conn, path)
    return conn


def table_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    return [row[1] for row in conn.execute(f'PRAGMA table_info("{table}")')]


def rows(conn: sqlite3.Connection, sql: str, params=()) -> list[dict]:
    return [dict(row) for row in conn.execute(sql, params).fetchall()]


def scalar(conn: sqlite3.Connection, sql: str, params=(), default=0):
    row = conn.execute(sql, params).fetchone()
    return row[0] if row and row[0] is not None else default


def utc_now() -> datetime:
    # Keep the database representation naive for desktop compatibility while
    # sourcing the value from an explicitly UTC-aware clock.
    return datetime.now(timezone.utc).replace(tzinfo=None)


def password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS)
    return f"pbkdf2_sha256${PASSWORD_ITERATIONS}${salt.hex()}${digest.hex()}"


def password_matches(password: str, stored: str | None) -> bool:
    stored = str(stored or "")
    if stored.startswith("pbkdf2_sha256$"):
        try:
            _, iterations, salt, expected = stored.split("$", 3)
            digest = hashlib.pbkdf2_hmac(
                "sha256", password.encode("utf-8"), bytes.fromhex(salt), int(iterations)
            ).hex()
            return secrets.compare_digest(digest, expected)
        except (TypeError, ValueError):
            return False
    legacy = hashlib.sha256(password.encode("utf-8")).hexdigest()
    return bool(stored) and secrets.compare_digest(legacy, stored)


def role_is_admin(role: str | None) -> bool:
    normalized = str(role or "").strip().casefold().replace("ö", "o").replace("ü", "u")
    return normalized in {"admin", "administrator", "yonetici", "superadmin"}


def public_user(user: dict | sqlite3.Row) -> dict:
    item = dict(user)
    return {
        "id": item.get("id"),
        "username": item.get("username") or "",
        "full_name": item.get("full_name") or item.get("username") or "",
        "email": item.get("email") or "",
        "role": item.get("role") or "User",
        "is_admin": role_is_admin(item.get("role")),
        "interface_edit_access": bool(item.get("interface_edit_access")) or role_is_admin(item.get("role")),
        "tenant_id": item.get("_tenant_id") or active_tenant_id() or None,
        "company_name": item.get("_company_name") or active_company_name() or "",
        "is_control_admin": is_control_admin(item),
        "can_access_control_center": can_access_control_center(item),
    }


def setting_value(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    return str(scalar(conn, "SELECT value FROM settings WHERE key=?", (key,), default=default) or default)


def upsert_setting(conn: sqlite3.Connection, table: str, key: str, value) -> None:
    if table not in {"settings", "internal_settings"}:
        raise ValueError("Geçersiz ayar tablosu")
    conn.execute(
        f'INSERT INTO "{table}" (key,value) VALUES (?,?) '
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, str(value or "")),
    )


def auth_status(token: str = "") -> dict:
    user = session_user(token) if token else None
    tenants = tenant_records()
    setup_required = not tenants
    with closing(db_connect() if user else registry_connect()) as conn:
        registration_enabled = setting_value(conn, "web_registration_enabled", "1") != "0"
        smtp_configured = bool(
            (setting_value(conn, "smtp_server") or setting_value(conn, "smtp_host"))
            and (setting_value(conn, "smtp_email") or setting_value(conn, "smtp_user"))
        )
    return {
        "ok": True,
        "setup_required": setup_required,
        "authenticated": bool(user),
        "registration_enabled": registration_enabled and not setup_required,
        "smtp_configured": smtp_configured,
        "user": public_user(user) if user else None,
        "tenants": [{"id": item["id"], "company_name": item["company_name"]} for item in tenants],
    }


def session_user(token: str) -> dict | None:
    if not token:
        return None
    if "." in token:
        tenant_id = token.partition(".")[0]
        tenant = tenant_by_id(tenant_id)
        if not tenant:
            clear_tenant_context()
            return None
        set_tenant_context(tenant)
    token_digest = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = utc_now().isoformat(timespec="seconds")
    with closing(db_connect()) as conn:
        row = conn.execute(
            """
            SELECT u.* FROM web_sessions s
            JOIN users u ON u.id=s.user_id
            WHERE s.token_hash=? AND s.expires_at>? AND COALESCE(u.active,1)=1
            """,
            (token_digest, now),
        ).fetchone()
        if not row:
            clear_tenant_context()
            return None
        conn.execute("UPDATE web_sessions SET last_seen_at=? WHERE token_hash=?", (now, token_digest))
        conn.commit()
        result = dict(row)
        result["_tenant_id"] = active_tenant_id()
        result["_company_name"] = active_company_name()
        return result


def create_session(user_id: int, remember: bool, user_agent: str, ip_address: str, tenant_id: str | None = None) -> tuple[str, int]:
    if tenant_id:
        tenant = tenant_by_id(tenant_id)
        if not tenant:
            raise LookupError("Firma bulunamadı.")
        set_tenant_context(tenant)
    tenant_id = tenant_id or active_tenant_id()
    token = f"{tenant_id}.{secrets.token_urlsafe(48)}" if tenant_id else secrets.token_urlsafe(48)
    now = utc_now()
    lifetime = timedelta(days=30 if remember else 1)
    max_age = int(lifetime.total_seconds())
    with closing(db_connect()) as conn:
        conn.execute("DELETE FROM web_sessions WHERE expires_at<=?", (now.isoformat(timespec="seconds"),))
        conn.execute(
            """
            INSERT INTO web_sessions
            (token_hash,user_id,created_at,expires_at,last_seen_at,remember,user_agent,ip_address)
            VALUES (?,?,?,?,?,?,?,?)
            """,
            (
                hashlib.sha256(token.encode("utf-8")).hexdigest(), user_id,
                now.isoformat(timespec="seconds"), (now + lifetime).isoformat(timespec="seconds"),
                now.isoformat(timespec="seconds"), int(remember), user_agent[:500], ip_address[:100],
            ),
        )
        conn.execute("UPDATE users SET auto_login=? WHERE id=?", (int(remember), user_id))
        conn.commit()
    return token, max_age


def delete_session(token: str) -> None:
    if not token:
        return
    if "." in token:
        tenant = tenant_by_id(token.partition(".")[0])
        if tenant:
            set_tenant_context(tenant)
    with closing(db_connect()) as conn:
        conn.execute(
            "DELETE FROM web_sessions WHERE token_hash=?",
            (hashlib.sha256(token.encode("utf-8")).hexdigest(),),
        )
        conn.commit()


def valid_email(value: str) -> bool:
    return bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value.strip()))


def normalize_identifier(value) -> str:
    """Normalize legacy desktop usernames and e-mail identifiers for login."""
    return unicodedata.normalize("NFKC", str(value or "")).strip().casefold()


def find_account_by_identifier(conn: sqlite3.Connection, identifier: str):
    needle = normalize_identifier(identifier)
    if not needle:
        return None
    # SQLite lower() is ASCII-focused. Comparing normalized values in Python
    # keeps old Turkish/Unicode usernames and legacy whitespace-compatible.
    for row in conn.execute("SELECT * FROM users WHERE COALESCE(active,1)=1"):
        if needle in {normalize_identifier(row["username"]), normalize_identifier(row["email"])}:
            return row
    return None


def validate_account(data: dict, require_company: bool = False) -> dict:
    clean = {
        "username": str(data.get("username") or "").strip(),
        "password": str(data.get("password") or ""),
        "full_name": str(data.get("full_name") or "").strip(),
        "email": str(data.get("email") or "").strip().lower(),
        "phone": str(data.get("phone") or "").strip(),
        "company_name": str(data.get("company_name") or "").strip(),
    }
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", clean["username"]):
        raise ValueError("Kullanıcı adı 3-40 karakter olmalı; harf, rakam, nokta, tire ve alt çizgi kullanılabilir.")
    if len(clean["full_name"]) < 3:
        raise ValueError("Ad soyad en az 3 karakter olmalıdır.")
    if not valid_email(clean["email"]):
        raise ValueError("Geçerli bir e-posta adresi girin.")
    if len(clean["password"]) < 8 or not re.search(r"[A-Za-z]", clean["password"]) or not re.search(r"\d", clean["password"]):
        raise ValueError("Parola en az 8 karakter olmalı ve en az bir harf ile bir rakam içermelidir.")
    if require_company and len(clean["company_name"]) < 2:
        raise ValueError("Firma adı zorunludur.")
    return clean


def send_registration_emails(member: dict, event: str = "registration") -> tuple[bool, str]:
    with closing(db_connect()) as conn:
        config = {row["key"]: row["value"] for row in conn.execute("SELECT key,value FROM settings")}
    smtp_host = str(config.get("smtp_server") or config.get("smtp_host") or "").strip()
    smtp_from = str(config.get("smtp_from") or config.get("smtp_email") or config.get("smtp_user") or "").strip()
    if not smtp_host or not smtp_from:
        return False, "SMTP ayarları tamamlanmadı; e-posta gönderilemedi."
    try:
        smtp_port = int(config.get("smtp_port") or 587)
    except (TypeError, ValueError):
        smtp_port = 587
    smtp_password = str(config.get("smtp_password") or "")
    smtp_username = str(config.get("smtp_username") or config.get("smtp_user") or smtp_from).strip()
    admin_email = str(config.get("admin_notification_email") or config.get("admin_email") or config.get("company_email") or smtp_from).strip()
    company_name = str(config.get("company_name") or "AYEC Pro").strip()
    member_email = str(member.get("email") or "").strip()
    if not valid_email(member_email) or not valid_email(admin_email):
        return False, "Üye veya yönetici e-posta adresi geçersiz."

    member_name = html.escape(str(member.get("full_name") or member.get("username") or "Kullanıcı"))
    username = html.escape(str(member.get("username") or ""))
    event_label = "ilk kurulum yöneticisi" if event == "setup" else "yeni kullanıcı"
    messages: list[EmailMessage] = []

    welcome = EmailMessage()
    welcome["Subject"] = f"{company_name} · AYEC Pro hesabınız hazır"
    welcome["From"] = smtp_from
    welcome["To"] = member_email
    welcome.set_content(f"Merhaba {member.get('full_name') or member.get('username')}, AYEC Pro hesabınız oluşturuldu. Kullanıcı adınız: {member.get('username')}")
    welcome.add_alternative(
        f"<div style='font-family:Segoe UI,Arial;padding:24px'><h2>Hoş geldiniz, {member_name}</h2>"
        f"<p><b>{html.escape(company_name)}</b> AYEC Pro hesabınız oluşturuldu.</p>"
        f"<p>Kullanıcı adınız: <b>{username}</b></p><p>Giriş adresi: http://85.117.239.60</p>"
        "<p>Güvenliğiniz için parolanız e-postada gösterilmez.</p></div>",
        subtype="html",
    )
    messages.append(welcome)

    notice = EmailMessage()
    notice["Subject"] = f"AYEC Pro · {event_label.title()} kaydı"
    notice["From"] = smtp_from
    notice["To"] = admin_email
    notice.set_content(f"{member.get('full_name')} ({member.get('username')}) için yeni hesap oluşturuldu: {member_email}")
    notice.add_alternative(
        f"<div style='font-family:Segoe UI,Arial;padding:24px'><h2>Yeni hesap kaydı</h2>"
        f"<p><b>Ad Soyad:</b> {member_name}</p><p><b>Kullanıcı:</b> {username}</p>"
        f"<p><b>E-posta:</b> {html.escape(member_email)}</p><p><b>Rol:</b> {html.escape(str(member.get('role') or 'User'))}</p></div>",
        subtype="html",
    )
    messages.append(notice)

    try:
        if smtp_port == 465 or setting_bool(config.get("smtp_ssl")):
            server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=20, context=ssl.create_default_context())
        else:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=20)
            server.ehlo()
            if str(config.get("smtp_tls", config.get("smtp_use_tls", "1"))) != "0":
                server.starttls(context=ssl.create_default_context())
                server.ehlo()
        recipients = [("üye", welcome, member_email), ("yönetici", notice, admin_email)]
        delivered: list[str] = []
        failed: list[str] = []
        with server:
            if smtp_password:
                server.login(smtp_username, smtp_password)
            for label, message, recipient in recipients:
                try:
                    server.send_message(message)
                    delivered.append(label)
                except Exception as error:
                    failed.append(f"{label}: {error}")
        if not failed:
            return True, "Üye ve yönetici e-postaları gönderildi."
        if delivered:
            return False, f"{', '.join(delivered)} e-postası gönderildi; {failed[0]} gönderilemedi."
        return False, f"E-postalar gönderilemedi: {failed[0]}"
    except Exception as error:
        return False, f"Hesap oluşturuldu fakat e-posta gönderilemedi: {error}"


def setting_bool(value) -> bool:
    return str(value or "").strip().casefold() in {"1", "true", "yes", "on", "evet", "aktif"}


def setup_application(data: dict, allow_existing: bool = False) -> dict:
    account = validate_account(data, require_company=True)
    sector = str(data.get("sector") or "teknik_servis")
    if sector not in {"teknik_servis", "otomotiv"}:
        sector = "teknik_servis"
    existing_tenants = tenant_records()
    if existing_tenants and not allow_existing:
        raise PermissionError("İlk kurulum daha önce tamamlanmış.")
    tenant = create_tenant(account["company_name"])
    set_tenant_context(tenant)
    with closing(db_connect()) as conn:
        if scalar(conn, "SELECT COUNT(*) FROM users", default=0):
            raise PermissionError("İlk kurulum daha önce tamamlanmış.")
        conn.execute("BEGIN IMMEDIATE")
        cursor = conn.execute(
            """
            INSERT INTO users (username,password,email,role,created_at,full_name,active,interface_edit_access)
            VALUES (?,?,?,?,?,?,1,1)
            """,
            (account["username"], password_hash(account["password"]), account["email"], "Admin", utc_now().isoformat(timespec="seconds"), account["full_name"]),
        )
        user_id = int(cursor.lastrowid)
        company_values = {
            "company_name": account["company_name"], "authorized_person": account["full_name"],
            "phone": account["phone"], "email": str(data.get("company_email") or account["email"]).strip(),
            "address": str(data.get("company_address") or "").strip(),
        }
        insert_available(conn, "company_info", company_values)
        settings = {
            "company_name": account["company_name"], "company_email": company_values["email"],
            "company_phone": account["phone"], "company_address": company_values["address"],
            "default_currency": str(data.get("currency") or "TRY"),
            "smtp_server": str(data.get("smtp_server") or "").strip(),
            "smtp_port": str(data.get("smtp_port") or "587"),
            "smtp_email": str(data.get("smtp_email") or "").strip(),
            "smtp_username": str(data.get("smtp_username") or data.get("smtp_email") or "").strip(),
            "smtp_password": str(data.get("smtp_password") or ""),
            "smtp_tls": "1", "admin_notification_email": str(data.get("admin_email") or account["email"]).strip(),
            "web_registration_enabled": "1", "web_setup_completed": "1",
        }
        for key, value in settings.items():
            upsert_setting(conn, "settings", key, value)
        upsert_setting(conn, "internal_settings", "current_sector", sector)
        upsert_setting(conn, "internal_settings", "web_setup_completed", "1")
        conn.commit()
        user = dict(conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone())
    sent, message = send_registration_emails(user, "setup")
    user["_tenant_id"] = tenant["id"]
    user["_company_name"] = tenant["company_name"]
    return {
        "ok": True,
        "tenant": {"id": tenant["id"], "company_name": tenant["company_name"], "db_filename": tenant["db_filename"]},
        "user": public_user(user), "mail_sent": sent, "mail_message": message,
    }


def register_account(data: dict, tenant_id: str | None = None) -> dict:
    account = validate_account(data)
    if tenant_id:
        tenant = tenant_by_id(tenant_id)
        if not tenant:
            raise LookupError("Firma bulunamadı.")
        set_tenant_context(tenant)
    if not active_tenant_id():
        if account["company_name"]:
            return setup_application(data, allow_existing=True)
        raise PermissionError("Firma seçimi gerekiyor. Yeni firma için firma adını girin.")
    with closing(db_connect()) as conn:
        if scalar(conn, "SELECT COUNT(*) FROM users", default=0) == 0:
            raise PermissionError("Önce ilk kurulum sihirbazını tamamlayın.")
        if setting_value(conn, "web_registration_enabled", "1") == "0":
            raise PermissionError("Yeni kullanıcı kaydı yönetici tarafından kapatılmış.")
        duplicate = find_account_by_identifier(conn, account["username"])
        duplicate = duplicate or find_account_by_identifier(conn, account["email"])
        if duplicate:
            raise ValueError("Bu kullanıcı adı veya e-posta zaten kayıtlı.")
        cursor = conn.execute(
            """
            INSERT INTO users (username,password,email,role,created_at,full_name,active,interface_edit_access)
            VALUES (?,?,?,?,?,?,1,0)
            """,
            (account["username"], password_hash(account["password"]), account["email"], "User", utc_now().isoformat(timespec="seconds"), account["full_name"]),
        )
        conn.commit()
        user = dict(conn.execute("SELECT * FROM users WHERE id=?", (cursor.lastrowid,)).fetchone())
    sent, message = send_registration_emails(user, "registration")
    user["_tenant_id"] = active_tenant_id()
    user["_company_name"] = active_company_name()
    return {"ok": True, "tenant": {"id": active_tenant_id(), "company_name": active_company_name()}, "user": public_user(user), "mail_sent": sent, "mail_message": message}


def authenticate_account(identifier: str, password: str, tenant_id: str | None = None) -> dict | None:
    clear_tenant_context()
    if tenant_id:
        selected = tenant_by_id(tenant_id)
        candidates = [selected] if selected else []
    else:
        candidates = tenant_records()
    for tenant in candidates:
        if not tenant:
            continue
        set_tenant_context(tenant)
        with closing(db_connect()) as conn:
            row = find_account_by_identifier(conn, identifier)
            if not row or not password_matches(password, row["password"]):
                continue
            if not str(row["password"] or "").startswith("pbkdf2_sha256$"):
                conn.execute("UPDATE users SET password=? WHERE id=?", (password_hash(password), row["id"]))
            conn.execute("UPDATE users SET last_login=? WHERE id=?", (utc_now().isoformat(timespec="seconds"), row["id"]))
            conn.commit()
            result = dict(conn.execute("SELECT * FROM users WHERE id=?", (row["id"],)).fetchone())
            result["_tenant_id"] = tenant["id"]
            result["_company_name"] = tenant["company_name"]
            return result
    clear_tenant_context()
    return None


def auth_rate_limited(client_key: str) -> bool:
    now = time.time()
    with _AUTH_LOCK:
        recent = [stamp for stamp in _AUTH_FAILURES.get(client_key, []) if now - stamp < 900]
        _AUTH_FAILURES[client_key] = recent
        return len(recent) >= 10


def record_auth_failure(client_key: str) -> None:
    with _AUTH_LOCK:
        _AUTH_FAILURES.setdefault(client_key, []).append(time.time())


def clear_auth_failures(client_key: str) -> None:
    with _AUTH_LOCK:
        _AUTH_FAILURES.pop(client_key, None)


def create_database_backup(prefix: str = "manual") -> Path:
    configured = os.environ.get("AYEC_BACKUP_DIR", "").strip()
    backup_dir = Path(configured).expanduser().resolve() if configured else ROOT / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"{prefix}-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.db"
    with closing(sqlite3.connect(active_db_path(), timeout=30)) as source:
        with closing(sqlite3.connect(target)) as destination:
            source.backup(destination)
            if destination.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("Otomatik yedek bütünlük kontrolünden geçemedi.")
            destination.commit()
    return target


def wipe_user_data(user: dict, password: str, phrase: str) -> dict:
    if not role_is_admin(user.get("role")):
        raise PermissionError("Wipe All yalnızca yönetici tarafından çalıştırılabilir.")
    if phrase.strip() != "TÜM VERİLERİ SİL":
        raise ValueError("Onay metni hatalı.")
    with closing(db_connect()) as conn:
        stored = conn.execute("SELECT password FROM users WHERE id=?", (user["id"],)).fetchone()
        if not stored or not password_matches(password, stored["password"]):
            raise PermissionError("Yönetici parolası hatalı.")
    backup = create_database_backup("pre-wipe")
    preserve = {
        "users", "settings", "internal_settings", "company_info", "web_sessions",
        "license_info", "registration", "sector_presets", "alembic_version",
        "schema_migrations", "app_labels", "device_brands", "product_bank_mappings",
        "automotive_maintenance_templates", "automotive_maintenance_template_items",
    }
    deleted: dict[str, int] = {}
    with closing(db_connect()) as conn:
        conn.execute("PRAGMA foreign_keys=OFF")
        conn.execute("BEGIN IMMEDIATE")
        tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for table in tables:
            if table in preserve:
                continue
            cursor = conn.execute(f'DELETE FROM "{table}"')
            deleted[table] = max(cursor.rowcount, 0)
        conn.commit()
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("VACUUM")
    return {
        "ok": True,
        "deleted_rows": sum(deleted.values()),
        "tables": {table: count for table, count in deleted.items() if count},
        "backup": backup.name,
    }


def insert_available(conn: sqlite3.Connection, table: str, values: dict) -> int:
    """Insert only columns present in an installed desktop database version."""
    columns = set(table_columns(conn, table))
    clean = {key: value for key, value in values.items() if key in columns}
    names = ",".join(f'"{key}"' for key in clean)
    marks = ",".join("?" for _ in clean)
    cursor = conn.execute(f'INSERT INTO "{table}" ({names}) VALUES ({marks})', tuple(clean.values()))
    return int(cursor.lastrowid)


def exchange_rates(refresh: bool = True) -> dict:
    """Return the same latest TCMB selling rates used by the desktop application."""
    result = {
        "TRY": {"currency": "TRY", "buying": 1.0, "selling": 1.0, "date": datetime.now().strftime("%Y-%m-%d"), "source": "Sabit"}
    }
    with db_connect() as conn:
        if refresh and scalar(conn, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='exchange_rates'"):
            try:
                today = datetime.now().strftime("%Y-%m-%d")
                has_today = scalar(conn, "SELECT COUNT(*) FROM exchange_rates WHERE DATE(effective_date)=DATE(?)", (today,))
                if not has_today:
                    request = Request(
                        "https://www.tcmb.gov.tr/kurlar/today.xml",
                        headers={"User-Agent": "AYEC-Pro/2.0"},
                    )
                    with urlopen(request, timeout=4) as response:
                        root = ElementTree.fromstring(response.read())
                    for node in root.findall("Currency"):
                        currency = str(node.get("CurrencyCode") or "").upper()
                        if currency not in {"USD", "EUR"}:
                            continue
                        buying_node = node.find("ForexBuying")
                        selling_node = node.find("ForexSelling")
                        buying = float(buying_node.text or 0) if buying_node is not None else 0
                        selling = float(selling_node.text or 0) if selling_node is not None else 0
                        if selling > 0:
                            insert_available(conn, "exchange_rates", {
                                "currency": currency, "buying_rate": buying or selling,
                                "selling_rate": selling,
                                "effective_date": now_text if (now_text := datetime.now().strftime("%Y-%m-%d %H:%M:%S")) else today,
                                "source": "TCMB", "created_at": now_text,
                            })
                    conn.commit()
            except Exception:
                # The last successful desktop rate remains usable when TCMB is temporarily unavailable.
                pass
        if scalar(conn, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='exchange_rates'"):
            for currency in ("USD", "EUR"):
                row = conn.execute(
                    """
                    SELECT currency,buying_rate,selling_rate,effective_date,source
                    FROM exchange_rates WHERE UPPER(currency)=?
                    ORDER BY datetime(created_at) DESC,id DESC LIMIT 1
                    """,
                    (currency,),
                ).fetchone()
                if row and float(row["selling_rate"] or 0) > 0:
                    result[currency] = {
                        "currency": currency,
                        "buying": float(row["buying_rate"] or row["selling_rate"]),
                        "selling": float(row["selling_rate"]),
                        "date": row["effective_date"] or "",
                        "source": row["source"] or "TCMB",
                    }
    return result


def resolve_exchange_rate(conn: sqlite3.Connection, currency: str, supplied=None) -> float:
    currency = str(currency or "TRY").upper()
    if currency == "TRY":
        return 1.0
    try:
        supplied_rate = float(supplied or 0)
    except (TypeError, ValueError):
        supplied_rate = 0.0
    if supplied_rate > 0:
        return supplied_rate
    row = conn.execute(
        "SELECT selling_rate FROM exchange_rates WHERE UPPER(currency)=? ORDER BY datetime(created_at) DESC,id DESC LIMIT 1",
        (currency,),
    ).fetchone()
    rate = float(row[0] or 0) if row else 0.0
    if rate <= 0:
        raise ValueError(f"{currency} satış kuru bulunamadı. Kur bilgisini güncelleyip tekrar deneyin.")
    return rate


def save_stock_card(data: dict) -> dict:
    """Save part, movement and purchase expense in one atomic desktop-compatible operation."""
    now = datetime.now()
    name = str(data.get("name") or "").strip()
    code = str(data.get("code") or "").strip()
    if not name or not code:
        raise ValueError("Stok kodu ve ürün adı zorunludur")
    currency = str(data.get("currency") or "TRY").upper()
    if currency not in {"TRY", "USD", "EUR"}:
        raise ValueError("Para birimi TRY, USD veya EUR olmalıdır")
    new_stock = max(0.0, float(data.get("stock") or 0))
    purchase_price = max(0.0, float(data.get("purchase_price") or 0))
    sale_price = max(0.0, float(data.get("price") or 0))
    row_id = int(data.get("id") or 0)
    with db_connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        old = None
        if row_id:
            old = conn.execute("SELECT * FROM parts WHERE id=? AND COALESCE(is_deleted,0)=0", (row_id,)).fetchone()
            if not old:
                raise LookupError("Stok kartı bulunamadı")
            old_stock = float(old["stock"] or 0)
            columns = set(table_columns(conn, "parts"))
            values = {
                "name": name, "part_name": name, "code": code,
                "barcode": str(data.get("barcode") or "").strip(),
                "category": str(data.get("category") or "Genel").strip(),
                "currency": currency, "stock": new_stock,
                "min_stock": max(0.0, float(data.get("min_stock") or 0)),
                "purchase_price": purchase_price, "price": sale_price,
                "brand": str(data.get("brand") or "").strip(),
                "description": str(data.get("description") or "").strip(),
            }
            clean = {key: value for key, value in values.items() if key in columns}
            conn.execute(
                f'UPDATE parts SET {",".join(f"\"{key}\"=?" for key in clean)} WHERE id=?',
                (*clean.values(), row_id),
            )
        else:
            old_stock = 0.0
            row_id = insert_available(conn, "parts", {
                "name": name, "part_name": name, "code": code,
                "barcode": str(data.get("barcode") or "").strip(),
                "category": str(data.get("category") or "Genel").strip(),
                "currency": currency, "stock": new_stock,
                "min_stock": max(0.0, float(data.get("min_stock") or 0)),
                "purchase_price": purchase_price, "price": sale_price,
                "brand": str(data.get("brand") or "").strip(),
                "description": str(data.get("description") or "").strip(),
                "created_at": now.isoformat(timespec="seconds"), "is_deleted": 0,
            })
        delta = round(new_stock - old_stock, 6)
        movement_id = None
        if delta:
            movement_id = insert_available(conn, "stock_movements", {
                "part_id": row_id,
                "movement_type": "Giriş" if delta > 0 else "Çıkış",
                "amount": abs(delta), "new_stock": new_stock,
                "description": "Ürün ekleme" if old is None else "Stok düzenleme",
                "created_at": now.isoformat(timespec="seconds"), "is_deleted": 0,
            })
        finance_id = None
        expense = round(max(delta, 0) * purchase_price, 4)
        rate = resolve_exchange_rate(conn, currency, data.get("exchange_rate")) if expense else (1.0 if currency == "TRY" else float(data.get("exchange_rate") or 0))
        if expense:
            ref_no = f"WEB-STOCK-{row_id}-{movement_id or 0}"
            finance_id = insert_available(conn, "accounting", {
                "type": "Gider", "category": "Stok Alımı" if old is None else "Stok Güncelleme",
                "amount": expense, "original_amount": expense,
                "try_equivalent": round(expense * rate, 4), "currency": currency,
                "exchange_rate": rate,
                "description": f"{'Stok Alımı' if old is None else 'Stok Güncelleme'}: {max(delta, 0):g} x {name}",
                "date": now.strftime("%Y-%m-%d"), "created_at": now.isoformat(timespec="seconds"),
                "payment_method": str(data.get("payment_method") or "Nakit"),
                "ref_no": ref_no, "product_service_id": row_id,
                "product_service_type": "stock", "is_deleted": 0,
                "selected_services": json.dumps({"part_id": row_id, "movement_id": movement_id, "quantity": max(delta, 0), "unit_cost": purchase_price, "currency": currency}, ensure_ascii=False),
            })
        conn.commit()
        part = dict(conn.execute("SELECT * FROM parts WHERE id=?", (row_id,)).fetchone())
    return {"ok": True, "id": row_id, "part": part, "delta": delta, "movement_id": movement_id, "finance_id": finance_id, "expense": expense, "currency": currency, "exchange_rate": rate}


def reconcile_stock_finance(part_ids: list[int]) -> list[dict]:
    """Idempotently repair stock cards saved by the former web flow without DB signals."""
    repaired = []
    now = datetime.now()
    exchange_rates(refresh=True)
    with db_connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        for part_id in part_ids:
            part_row = conn.execute("SELECT * FROM parts WHERE id=? AND COALESCE(is_deleted,0)=0", (int(part_id),)).fetchone()
            if not part_row:
                continue
            part = dict(part_row)
            marker = f"WEB-STOCK-RECONCILE-{part_id}"
            if conn.execute("SELECT 1 FROM accounting WHERE ref_no=? LIMIT 1", (marker,)).fetchone():
                continue
            stock = max(0.0, float(part.get("stock") or 0))
            purchase_price = max(0.0, float(part.get("purchase_price") or 0))
            if stock <= 0 or purchase_price <= 0:
                continue
            movement = conn.execute(
                "SELECT id FROM stock_movements WHERE part_id=? AND COALESCE(is_deleted,0)=0 AND movement_type LIKE 'Giriş%' ORDER BY id LIMIT 1",
                (part_id,),
            ).fetchone()
            movement_id = int(movement[0]) if movement else insert_available(conn, "stock_movements", {
                "part_id": part_id, "movement_type": "Giriş", "amount": stock, "new_stock": stock,
                "description": "Web stok sinyali düzeltmesi", "created_at": part.get("created_at") or now.isoformat(timespec="seconds"), "is_deleted": 0,
            })
            currency = str(part.get("currency") or "TRY").upper()
            rate = resolve_exchange_rate(conn, currency)
            expense = round(stock * purchase_price, 4)
            finance_id = insert_available(conn, "accounting", {
                "type": "Gider", "category": "Stok Alımı", "amount": expense,
                "original_amount": expense, "try_equivalent": round(expense * rate, 4),
                "currency": currency, "exchange_rate": rate,
                "description": f"Stok Alımı: {stock:g} x {part.get('name') or part.get('part_name') or ''}",
                "date": str(part.get("created_at") or now.strftime("%Y-%m-%d"))[:10],
                "created_at": part.get("created_at") or now.isoformat(timespec="seconds"),
                "payment_method": "Nakit", "ref_no": marker,
                "product_service_id": part_id, "product_service_type": "stock", "is_deleted": 0,
                "selected_services": json.dumps({"repair": True, "part_id": part_id, "movement_id": movement_id, "quantity": stock, "unit_cost": purchase_price, "currency": currency}, ensure_ascii=False),
            })
            repaired.append({"part_id": part_id, "movement_id": movement_id, "finance_id": finance_id, "expense": expense, "currency": currency, "try_equivalent": round(expense * rate, 4)})
        conn.commit()
    return repaired


def _customer_balance(conn: sqlite3.Connection, customer_id: int, currency: str) -> float:
    row = conn.execute(
        "SELECT balance FROM customer_currency_balances WHERE customer_id=? AND currency=?",
        (customer_id, currency),
    ).fetchone()
    return float(row[0] or 0) if row else 0.0


def _set_customer_balance(conn: sqlite3.Connection, customer_id: int, currency: str, balance: float, now: datetime) -> None:
    conn.execute(
        """
        INSERT INTO customer_currency_balances (customer_id,currency,balance,last_updated)
        VALUES (?,?,?,?)
        ON CONFLICT(customer_id,currency) DO UPDATE SET balance=excluded.balance,last_updated=excluded.last_updated
        """,
        (customer_id, currency, balance, now.isoformat(timespec="seconds")),
    )


def commit_sales_hub(data: dict) -> dict:
    """Execute Sales Hub proforma, paid sale or service signal as one database transaction."""
    mode = str(data.get("mode") or "").lower()
    if mode not in {"proforma", "payment", "service"}:
        raise ValueError("Geçersiz Sales Hub işlemi")
    customer_name_hint = str(data.get("customer_name") or "").strip()
    try:
        customer_id = int(data.get("customer_id") or 0)
    except (TypeError, ValueError):
        customer_id = 0
    if not customer_id and not customer_name_hint:
        raise ValueError("Müşteri seçilmelidir")
    raw_lines = data.get("lines") or []
    if not isinstance(raw_lines, list) or not raw_lines:
        raise ValueError("Sepette en az bir ürün bulunmalıdır")
    currency = str(data.get("currency") or "TRY").upper()
    if currency not in {"TRY", "USD", "EUR"}:
        raise ValueError("Geçersiz teklif para birimi")
    rates = data.get("rates") if isinstance(data.get("rates"), dict) else {}
    now = datetime.now()
    vat_percent = max(0.0, min(float(data.get("vat_rate") or 0), 100.0))
    with db_connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        if not customer_id and customer_name_hint:
            customer_match = conn.execute(
                "SELECT id FROM customers WHERE lower(trim(name))=lower(trim(?)) "
                "AND COALESCE(is_deleted,0)=0 ORDER BY id DESC LIMIT 1",
                (customer_name_hint,),
            ).fetchone()
            if customer_match:
                customer_id = int(customer_match["id"])
        if not customer_id:
            raise ValueError("M\u00fc\u015fteri se\u00e7ilmelidir")
        customer_row = conn.execute("SELECT * FROM customers WHERE id=? AND COALESCE(is_deleted,0)=0", (customer_id,)).fetchone()
        if not customer_row:
            raise LookupError("Müşteri kaydı bulunamadı")
        customer = dict(customer_row)
        selected_rate = resolve_exchange_rate(conn, currency, data.get("exchange_rate") or rates.get(currency))
        lines = []
        subtotal_try = 0.0
        total_cost_try = 0.0
        for raw in raw_lines:
            part_id = int(raw.get("product_id") or raw.get("part_id") or 0)
            quantity = max(0.0, float(raw.get("qty") or 0))
            if not part_id or quantity <= 0:
                raise ValueError("Sepet satırı geçersiz")
            part_row = conn.execute("SELECT * FROM parts WHERE id=? AND COALESCE(is_deleted,0)=0", (part_id,)).fetchone()
            if not part_row:
                raise LookupError("Sepetteki stok kartlarından biri bulunamadı")
            part = dict(part_row)
            if mode == "payment" and quantity > float(part.get("stock") or 0):
                raise ValueError(f"{part.get('name') or part.get('part_name')} için yeterli stok yok")
            source_currency = str(part.get("currency") or "TRY").upper()
            source_rate = resolve_exchange_rate(conn, source_currency, rates.get(source_currency))
            unit_try = round(float(part.get("price") or 0) * source_rate, 6)
            unit_selected = round(unit_try / selected_rate, 6)
            cost_try = round(float(part.get("purchase_price") or 0) * source_rate, 6)
            line_try = unit_try * quantity
            subtotal_try += line_try
            total_cost_try += cost_try * quantity
            lines.append({
                "part": part, "part_id": part_id, "qty": quantity,
                "source_currency": source_currency, "source_rate": source_rate,
                "unit_try": unit_try, "unit_selected": unit_selected,
                "line_try": line_try, "line_selected": line_try / selected_rate,
            })
        subtotal_try = round(subtotal_try, 4)
        vat_try = round(subtotal_try * vat_percent / 100.0, 4)
        total_try = round(subtotal_try + vat_try, 4)
        subtotal = round(subtotal_try / selected_rate, 4)
        vat_amount = round(vat_try / selected_rate, 4)
        total = round(total_try / selected_rate, 4)
        symbol = {"TRY": "₺", "USD": "$", "EUR": "€"}[currency]
        customer_name = customer.get("name") or customer.get("customer_name") or ""
        # Proforma issuer comes from Firma AyarlarÄ±. The customer remains the
        # recipient/contact; it must not replace the issuer company name.
        issuer_company = setting_value(conn, "company_name", "").strip()
        if not issuer_company:
            company_row = conn.execute(
                "SELECT company_name FROM company_info ORDER BY id DESC LIMIT 1"
            ).fetchone()
            issuer_company = str(company_row["company_name"] if company_row else "").strip()
        if not issuer_company:
            issuer_company = str(customer.get("company_name") or customer_name or "AYEC Pro").strip()
        result = {
            "ok": True, "mode": mode, "currency": currency, "currency_symbol": symbol,
            "exchange_rate": selected_rate, "subtotal": subtotal, "vat_amount": vat_amount,
            "total": total, "subtotal_try": subtotal_try, "vat_amount_try": vat_try,
            "total_try": total_try,
        }
        if mode == "proforma":
            offer_no = str(data.get("offer_no") or f"PRF-{now.year}-{now.strftime('%m%d%H%M%S')}")
            offer_payload = {
                "offer_no": offer_no, "customer_id": customer_id, "customer_name": customer_name,
                "company_name": issuer_company,
                "contact_name": customer_name, "project_name": str(data.get("project_name") or ""),
                "template_type": str(data.get("template_type") or "modern"),
                "currency_code": currency, "currency_symbol": symbol, "exchange_rate": selected_rate,
                "subtotal": subtotal, "discount": 0, "vat_rate": vat_percent / 100.0,
                "vat_amount": vat_amount, "total": total, "subtotal_try": subtotal_try,
                "discount_try": 0, "vat_amount_try": vat_try, "total_try": total_try,
                "status": "Teklif", "source": "Web Sales Hub", "created_at": now.isoformat(timespec="seconds"),
            }
            offer_payload["payload_json"] = json.dumps({**offer_payload, "items": [{"productId": item["part_id"], "name": item["part"].get("name"), "qty": item["qty"], "price": item["unit_selected"], "price_try": item["unit_try"]} for item in lines]}, ensure_ascii=False)
            offer_id = insert_available(conn, "offers", offer_payload)
            item_ids = []
            for item in lines:
                part = item["part"]
                item_ids.append(insert_available(conn, "offer_items", {
                    "offer_id": offer_id, "item_id": item["part_id"], "item_type": "stock",
                    "service": part.get("name") or part.get("part_name") or "",
                    "description": part.get("description") or part.get("name") or "",
                    "brand": part.get("brand") or "", "qty": item["qty"],
                    "unit_price": item["unit_selected"], "line_total": item["line_selected"],
                    "payload_json": json.dumps({"code": part.get("code"), "currency": currency, "unit_try": item["unit_try"], "source_currency": item["source_currency"]}, ensure_ascii=False),
                }))
            result.update({"offer_id": offer_id, "offer_no": offer_no, "item_ids": item_ids})
        elif mode == "payment":
            sale_no = str(data.get("reference") or f"SAT-{now.strftime('%Y%m%d%H%M%S')}")
            income_id = insert_available(conn, "accounting", {
                "type": "Gelir", "category": "Satış", "amount": total,
                "original_amount": total, "try_equivalent": total_try, "currency": currency,
                "exchange_rate": selected_rate, "description": f"{sale_no} Sales Hub peşin satış",
                "date": now.strftime("%Y-%m-%d"), "created_at": now.isoformat(timespec="seconds"),
                "customer_id": customer_id, "customer_name": customer_name,
                "payment_method": str(data.get("payment_method") or "Web"), "tracking_no": sale_no,
                "ref_no": sale_no, "is_deleted": 0,
            })
            cost_id = None
            if total_cost_try > 0:
                cost_id = insert_available(conn, "accounting", {
                    "type": "Gider", "category": "Satılan Malın Maliyeti", "amount": round(total_cost_try, 4),
                    "original_amount": round(total_cost_try, 4), "try_equivalent": round(total_cost_try, 4),
                    "currency": "TRY", "exchange_rate": 1,
                    "description": f"Satılan Malın Maliyeti - {sale_no} ({len(lines)} kalem)",
                    "date": now.strftime("%Y-%m-%d"), "created_at": now.isoformat(timespec="seconds"),
                    "customer_id": customer_id, "customer_name": customer_name,
                    "payment_method": "Mahsup", "tracking_no": sale_no, "ref_no": sale_no, "is_deleted": 0,
                })
            movement_ids = []
            for item in lines:
                new_stock = round(float(item["part"].get("stock") or 0) - item["qty"], 6)
                conn.execute("UPDATE parts SET stock=? WHERE id=?", (new_stock, item["part_id"]))
                movement_ids.append(insert_available(conn, "stock_movements", {
                    "part_id": item["part_id"], "movement_type": "Çıkış", "amount": item["qty"],
                    "new_stock": new_stock, "description": f"{sale_no} Sales Hub peşin satış",
                    "created_at": now.isoformat(timespec="seconds"), "is_deleted": 0,
                }))
            current_balance = _customer_balance(conn, customer_id, currency)
            # Desktop convention: a debit (sale/service) makes the customer
            # balance more negative; a credit (payment) brings it back toward
            # zero.  Keeping this sign is what lets the web payment dialog
            # calculate the actual open debt.
            debit_balance = round(current_balance - total, 4)
            debit_id = insert_available(conn, "currency_transactions", {
                "customer_id": customer_id, "transaction_type": "DEBIT", "amount": total,
                "currency": currency, "exchange_rate": selected_rate, "try_equivalent": total_try,
                "description": f"Peşin satış borç kaydı: {sale_no}", "tracking_no": sale_no,
                "created_at": now.isoformat(timespec="seconds"), "current_balance": debit_balance,
            })
            credit_id = insert_available(conn, "currency_transactions", {
                "customer_id": customer_id, "transaction_type": "CREDIT", "amount": total,
                "currency": currency, "exchange_rate": selected_rate, "try_equivalent": total_try,
                "description": f"Peşin satış tahsilatı: {sale_no}", "tracking_no": sale_no,
                "created_at": now.isoformat(timespec="seconds"), "current_balance": current_balance,
            })
            _set_customer_balance(conn, customer_id, currency, current_balance, now)
            result.update({"reference": sale_no, "income_id": income_id, "cost_id": cost_id, "movement_ids": movement_ids, "debit_id": debit_id, "credit_id": credit_id})
        else:
            service_no = str(data.get("reference") or f"SRV-{now.strftime('%Y%m%d%H%M%S')}")
            product_names = ", ".join(str(item["part"].get("name") or item["part"].get("part_name") or "") for item in lines)
            device_id = insert_available(conn, "devices", {
                "tracking_no": service_no, "customer_id": customer_id, "customer_name": customer_name,
                "device_type": str(data.get("device_type") or "Cihaz"), "device_model": product_names,
                "fault_description": f"Sales Hub kaydı — {data.get('offer_no') or service_no}",
                "repair_details": f"Sepet toplamı: {total:g} {currency} | TRY karşılığı: {total_try:g}",
                "status": "Bekliyor", "entry_date": now.strftime("%Y-%m-%d"),
                "estimated_date": data.get("estimated_date") or None,
                "service_source": "Web Sales Hub", "priority": "Normal", "payment_status": "Beklemede",
                "price": total, "created_at": now.isoformat(timespec="seconds"), "is_deleted": 0,
            })
            current_balance = _customer_balance(conn, customer_id, currency)
            debit_balance = round(current_balance - total, 4)
            debit_id = insert_available(conn, "currency_transactions", {
                "customer_id": customer_id, "transaction_type": "DEBIT", "amount": total,
                "currency": currency, "exchange_rate": selected_rate, "try_equivalent": total_try,
                "description": f"Servis borç kaydı: {service_no}", "tracking_no": service_no,
                "created_at": now.isoformat(timespec="seconds"), "current_balance": debit_balance,
            })
            _set_customer_balance(conn, customer_id, currency, debit_balance, now)
            result.update({"reference": service_no, "device_id": device_id, "device": product_names, "debit_id": debit_id})
        conn.commit()
    return result


def update_technician_job(data: dict) -> dict:
    """Apply technician form, used-part stock signal and optional collection atomically."""
    device_id = int(data.get("device_id") or 0)
    tracking_no = str(data.get("tracking_no") or "").strip()
    if not device_id and not tracking_no:
        raise ValueError("Servis kaydı belirtilmedi")
    now = datetime.now()
    with db_connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        device_row = conn.execute(
            "SELECT * FROM devices WHERE " + ("id=?" if device_id else "tracking_no=?") + " AND COALESCE(is_deleted,0)=0",
            (device_id if device_id else tracking_no,),
        ).fetchone()
        if not device_row:
            raise LookupError("Servis kaydı bulunamadı")
        device = dict(device_row)
        device_id = int(device["id"])
        tracking_no = str(device.get("tracking_no") or tracking_no)
        columns = set(table_columns(conn, "devices"))
        candidate = {
            "status": data.get("status") or device.get("status") or "Bekliyor",
            "technician": str(data.get("technician") or ""),
            "internal_notes": str(data.get("internal_notes") or ""),
            "repair_details": str(data.get("repair_details") or ""),
            "labor_cost": max(0.0, float(data.get("labor_cost") or 0)),
            "cargo_fee": max(0.0, float(data.get("cargo_fee") or 0)),
            "delivery_type": str(data.get("delivery_type") or ""),
            "payment_status": str(data.get("payment_status") or device.get("payment_status") or "Beklemede"),
            "warranty_status": str(data.get("warranty_status") or device.get("warranty_status") or "Yok"),
            "warranty_end_date": data.get("warranty_end_date") or None,
            "estimated_date": data.get("estimated_date") or device.get("estimated_date"),
            "priority": str(data.get("priority") or device.get("priority") or "Normal"),
            "updated_at": now.isoformat(timespec="seconds"),
        }
        if str(candidate["status"]).lower() in {"tamamlandı", "teslim edildi"} and "exit_date" in columns:
            candidate["exit_date"] = now.strftime("%Y-%m-%d")
        clean = {key: value for key, value in candidate.items() if key in columns}
        conn.execute(f'UPDATE devices SET {",".join(f"\"{key}\"=?" for key in clean)} WHERE id=?', (*clean.values(), device_id))
        movement_id = used_part_id = None
        part_id = int(data.get("part_id") or 0)
        quantity = max(0.0, float(data.get("part_quantity") or 0))
        if part_id and quantity:
            part_row = conn.execute("SELECT * FROM parts WHERE id=? AND COALESCE(is_deleted,0)=0", (part_id,)).fetchone()
            if not part_row:
                raise LookupError("Kullanılacak stok kartı bulunamadı")
            part = dict(part_row)
            old_stock = float(part.get("stock") or 0)
            if quantity > old_stock:
                raise ValueError(f"{part.get('name') or part.get('part_name')} için yeterli stok yok")
            new_stock = round(old_stock - quantity, 6)
            conn.execute("UPDATE parts SET stock=? WHERE id=?", (new_stock, part_id))
            movement_id = insert_available(conn, "stock_movements", {
                "part_id": part_id, "movement_type": "Çıkış", "amount": quantity,
                "new_stock": new_stock, "description": f"{tracking_no} teknisyen kullanımı",
                "created_at": now.isoformat(timespec="seconds"), "is_deleted": 0,
            })
            used_part_id = insert_available(conn, "used_parts", {
                "tracking_no": tracking_no, "part_id": part_id,
                "part_name": part.get("name") or part.get("part_name") or "",
                "price": float(part.get("price") or 0), "quantity": quantity,
                "purchase_price_snapshot": float(part.get("purchase_price") or 0),
                "currency": str(part.get("currency") or "TRY"),
                "created_at": now.isoformat(timespec="seconds"), "is_deleted": 0,
            })
        # Technician labour/cargo is a service debit when it is first entered.
        # This keeps the customer balance negative until a real payment is
        # recorded, matching the desktop currency mixin.
        service_customer_id = int(device.get("customer_id") or 0)
        service_charge = round(float(candidate.get("labor_cost") or 0) + float(candidate.get("cargo_fee") or 0), 4)
        if service_customer_id and service_charge > 0:
            existing_debit = scalar(
                conn,
                "SELECT COUNT(*) FROM currency_transactions WHERE customer_id=? AND currency='TRY' AND transaction_type='DEBIT' AND tracking_no=?",
                (service_customer_id, tracking_no),
            )
            if not existing_debit:
                current_service_balance = _customer_balance(conn, service_customer_id, "TRY")
                service_debit_balance = round(current_service_balance - service_charge, 4)
                insert_available(conn, "currency_transactions", {
                    "customer_id": service_customer_id, "transaction_type": "DEBIT", "amount": service_charge,
                    "currency": "TRY", "exchange_rate": 1, "try_equivalent": service_charge,
                    "description": f"Servis hizmet borcu: {tracking_no}", "tracking_no": tracking_no,
                    "created_at": now.isoformat(timespec="seconds"), "current_balance": service_debit_balance,
                })
                _set_customer_balance(conn, service_customer_id, "TRY", service_debit_balance, now)
        finance_id = currency_transaction_id = None
        payment = max(0.0, float(data.get("payment_amount") or 0)) if data.get("collect_payment") else 0.0
        payment_currency = str(data.get("payment_currency") or "TRY").upper()
        if payment:
            if not int(device.get("customer_id") or 0):
                raise ValueError("Tahsilat için servis müşterisi bulunamadı")
            rate = resolve_exchange_rate(conn, payment_currency, data.get("exchange_rate"))
            customer_id = int(device.get("customer_id") or 0)
            customer_name = str(device.get("customer_name") or "")
            finance_id = insert_available(conn, "accounting", {
                "type": "Gelir", "category": "Tahsilat", "amount": payment,
                "original_amount": payment, "try_equivalent": round(payment * rate, 4),
                "currency": payment_currency, "exchange_rate": rate,
                "description": f"Servis Tahsilatı: {tracking_no}",
                "date": now.strftime("%Y-%m-%d"), "created_at": now.isoformat(timespec="seconds"),
                "customer_id": customer_id or None, "customer_name": customer_name,
                "payment_method": str(data.get("payment_method") or "Nakit"),
                "tracking_no": tracking_no, "ref_no": tracking_no, "is_deleted": 0,
            })
            if customer_id:
                current = _customer_balance(conn, customer_id, payment_currency)
                open_debt = max(0.0, -current)
                if open_debt <= 0:
                    raise ValueError("Bu para biriminde açık borç bulunmuyor")
                if payment > open_debt + 0.0001:
                    raise ValueError(f"Tahsilat açık borcu aşamaz (en fazla {open_debt:g} {payment_currency})")
                updated = round(current + payment, 4)
                currency_transaction_id = insert_available(conn, "currency_transactions", {
                    "customer_id": customer_id, "transaction_type": "CREDIT", "amount": payment,
                    "currency": payment_currency, "exchange_rate": rate,
                    "try_equivalent": round(payment * rate, 4),
                    "description": f"Servis tahsilatı: {tracking_no}", "tracking_no": tracking_no,
                    "created_at": now.isoformat(timespec="seconds"), "current_balance": updated,
                })
                _set_customer_balance(conn, customer_id, payment_currency, updated, now)
            if "payment_status" in columns:
                conn.execute("UPDATE devices SET payment_status=? WHERE id=?", ("Ödendi", device_id))
        conn.commit()
    return {"ok": True, "device_id": device_id, "tracking_no": tracking_no, "movement_id": movement_id, "used_part_id": used_part_id, "finance_id": finance_id, "currency_transaction_id": currency_transaction_id}


def record_customer_payment(data: dict) -> dict:
    """Record a customer credit only up to the current open debt.

    The balance sign follows the desktop application: negative means the
    customer owes the company, and a CREDIT increases the balance toward zero.
    """
    try:
        customer_id = int(data.get("customer_id") or 0)
    except (TypeError, ValueError):
        customer_id = 0
    customer_name_hint = str(data.get("customer_name") or "").strip()
    currency = str(data.get("currency") or "TRY").upper()
    if currency not in {"TRY", "USD", "EUR"}:
        raise ValueError("Para birimi TRY, USD veya EUR olmalıdır")
    try:
        amount = round(float(data.get("amount") or 0), 4)
    except (TypeError, ValueError):
        amount = 0.0
    if amount <= 0:
        raise ValueError("Tahsilat tutarı sıfırdan büyük olmalıdır")
    now = datetime.now()
    with db_connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        if not customer_id and customer_name_hint:
            match = conn.execute(
                "SELECT id FROM customers WHERE lower(trim(name))=lower(trim(?)) AND COALESCE(is_deleted,0)=0 ORDER BY id DESC LIMIT 1",
                (customer_name_hint,),
            ).fetchone()
            if match:
                customer_id = int(match["id"])
        if not customer_id:
            raise ValueError("Müşteri seçilmelidir")
        customer_row = conn.execute(
            "SELECT * FROM customers WHERE id=? AND COALESCE(is_deleted,0)=0", (customer_id,)
        ).fetchone()
        if not customer_row:
            raise LookupError("Müşteri kaydı bulunamadı")
        customer = dict(customer_row)
        current = _customer_balance(conn, customer_id, currency)
        open_debt = max(0.0, -current)
        if open_debt <= 0:
            raise ValueError("Bu para biriminde açık borç bulunmuyor")
        if amount > open_debt + 0.0001:
            raise ValueError(f"Tahsilat açık borcu aşamaz (en fazla {open_debt:g} {currency})")
        rate = resolve_exchange_rate(conn, currency, data.get("exchange_rate"))
        updated = round(current + amount, 4)
        reference = str(data.get("reference") or data.get("tracking_no") or "").strip()
        description = str(data.get("description") or "Müşteri tahsilatı").strip()
        method = str(data.get("payment_method") or "Web").strip()
        customer_name = customer.get("name") or customer.get("customer_name") or customer_name_hint
        finance_id = insert_available(conn, "accounting", {
            "type": "Gelir", "category": "Tahsilat", "amount": amount,
            "original_amount": amount, "try_equivalent": round(amount * rate, 4),
            "currency": currency, "exchange_rate": rate, "description": description,
            "date": now.strftime("%Y-%m-%d"), "created_at": now.isoformat(timespec="seconds"),
            "customer_id": customer_id, "customer_name": customer_name,
            "payment_method": method, "tracking_no": reference, "ref_no": reference, "is_deleted": 0,
        })
        transaction_id = insert_available(conn, "currency_transactions", {
            "customer_id": customer_id, "transaction_type": "CREDIT", "amount": amount,
            "currency": currency, "exchange_rate": rate, "try_equivalent": round(amount * rate, 4),
            "description": description, "tracking_no": reference,
            "created_at": now.isoformat(timespec="seconds"), "current_balance": updated,
        })
        _set_customer_balance(conn, customer_id, currency, updated, now)
        conn.commit()
    return {
        "ok": True, "finance_id": finance_id, "currency_transaction_id": transaction_id,
        "customer_id": customer_id, "customer_name": customer_name, "currency": currency,
        "amount": amount, "open_debt_before": open_debt, "open_debt_after": max(0.0, -updated),
        "exchange_rate": rate, "try_equivalent": round(amount * rate, 4),
        "payment_method": method, "reference": reference,
    }


def resolve_logo_path(value) -> Path | None:
    """Resolve project-relative logos and migrated Windows paths on every server OS."""
    raw = str(value or "").strip()
    if not raw:
        return None
    candidate = Path(raw).expanduser()
    if candidate.is_file():
        return candidate.resolve()
    if not candidate.is_absolute():
        project_candidate = (ROOT / candidate).resolve()
        if project_candidate.is_file():
            return project_candidate
    filename = PureWindowsPath(raw).name
    migrated = (WEB_ROOT / "uploads" / filename).resolve()
    return migrated if filename and migrated.is_file() else None


class _PDFSettingsAdapter:
    def __init__(self, values: dict[str, str]):
        self.values = values

    def get_setting(self, key, default=""):
        value = self.values.get(key)
        if key == "logo_path":
            logo = resolve_logo_path(value)
            return str(logo) if logo else default
        return default if value in (None, "") else value


def build_offer_pdf(offer_id: int, requested_template: str | None = None) -> tuple[Path, str]:
    """Generate a proforma with the desktop application's own three PDF templates."""
    allowed_templates = {"modern", "corporate", "minimal"}
    with db_connect() as conn:
        offer_row = conn.execute("SELECT * FROM offers WHERE id=?", (offer_id,)).fetchone()
        if not offer_row:
            raise ValueError("Teklif kaydı bulunamadı")
        offer = dict(offer_row)
        item_rows = rows(conn, "SELECT * FROM offer_items WHERE offer_id=? ORDER BY id", (offer_id,))
        settings = {row["key"]: row["value"] for row in rows(conn, "SELECT key,value FROM settings")}
        company_row = conn.execute("SELECT * FROM company_info ORDER BY id DESC LIMIT 1").fetchone()
        company_info = dict(company_row) if company_row else {}
        customer_company = ""
        if offer.get("customer_id"):
            customer_row = conn.execute(
                "SELECT COALESCE(company_name, '') AS company_name FROM customers WHERE id=?",
                (offer.get("customer_id"),),
            ).fetchone()
            customer_company = str(customer_row["company_name"] if customer_row else "").strip()
    conn.close()

    # Older offers stored the selected customer's name in company_name. Fill
    # missing settings from company_info and prefer the current issuer when a
    # previously saved proforma is opened again.
    for setting_key, info_key in {
        "company_name": "company_name",
        "company_phone": "phone",
        "company_email": "email",
        "company_address": "address",
        "logo_path": "logo_path",
    }.items():
        if not str(settings.get(setting_key) or "").strip() and str(company_info.get(info_key) or "").strip():
            settings[setting_key] = company_info[info_key]
    issuer_company = str(
        settings.get("company_name")
        or offer.get("company_name")
        or offer.get("customer_name")
        or "AYEC Pro"
    ).strip()

    template = requested_template if requested_template in allowed_templates else offer.get("template_type")
    if template not in allowed_templates:
        template = "modern"
    vat_rate = float(offer.get("vat_rate") or 0)
    if vat_rate > 1:
        vat_rate /= 100
    totals = (
        float(offer.get("subtotal") or 0),
        float(offer.get("discount") or 0),
        vat_rate,
        float(offer.get("vat_amount") or 0),
        float(offer.get("total") or 0),
    )
    cart_items = []
    for item in item_rows:
        try:
            payload = json.loads(item.get("payload_json") or "{}")
        except (TypeError, ValueError):
            payload = {}
        cart_items.append({
            "service": item.get("service") or payload.get("name") or "Ürün / Hizmet",
            "name": item.get("service") or payload.get("name") or "Ürün / Hizmet",
            "description": item.get("description") or payload.get("description") or item.get("service") or "-",
            "brand": item.get("brand") or payload.get("brand") or "",
            "model": payload.get("model") or "",
            "code": payload.get("code") or "",
            "qty": float(item.get("qty") or payload.get("qty") or 1),
            "price": float(item.get("unit_price") or payload.get("price") or 0),
        })
    if not cart_items:
        try:
            payload = json.loads(offer.get("payload_json") or "{}")
            cart_items = payload.get("items") or []
        except (TypeError, ValueError):
            cart_items = []

    ensure_packaged_source()
    from src.utils.pdf_manager import PDFManagerQt

    handle = tempfile.NamedTemporaryFile(prefix=f"{offer.get('offer_no') or 'proforma'}-", suffix=".pdf", delete=False)
    target = Path(handle.name)
    handle.close()
    manager = PDFManagerQt(_PDFSettingsAdapter(settings))
    manager._open_file = lambda _filename: None
    currency = offer.get("currency_symbol") or {"TRY": "₺", "USD": "$", "EUR": "€"}.get(offer.get("currency_code"), "₺")
    success, result = manager.create_proforma(
        template_type=template,
        cart_items=cart_items,
        totals=totals,
        company_name=issuer_company,
        customer_name=offer.get("customer_name") or "Sayın İlgili",
        project_name=offer.get("project_name") or "",
        contact_name=offer.get("contact_name") or offer.get("customer_name") or "",
        reference_no=offer.get("offer_no") or f"PRF-{offer_id}",
        offer_date=offer.get("created_at"),
        customer_company=customer_company,
        currency_code=offer.get("currency_code") or "TRY",
        save_path=str(target),
        currency=currency,
    )
    if not success or not target.exists():
        target.unlink(missing_ok=True)
        raise RuntimeError(str(result))
    return target, str(offer.get("offer_no") or f"PRF-{offer_id}")


def delete_stock_with_reversal(part_id: int) -> dict:
    """Mirror the desktop stock context-menu deletion and finance reversal atomically."""
    now = datetime.now()
    exchange_rates(refresh=True)
    with db_connect() as conn:
        part_row = conn.execute(
            "SELECT id,name,stock,purchase_price,currency FROM parts WHERE id=? AND COALESCE(is_deleted,0)=0",
            (part_id,),
        ).fetchone()
        if not part_row:
            raise LookupError("Stok kartı bulunamadı veya daha önce silinmiş")
        part = dict(part_row)
        stock = float(part.get("stock") or 0)
        purchase_price = float(part.get("purchase_price") or 0)
        currency = str(part.get("currency") or "TRY").upper()
        movement_id = insert_available(conn, "stock_movements", {
            "part_id": part_id,
            "movement_type": "Çıkış (Silindi)",
            "amount": -stock,
            "new_stock": 0,
            "description": f"Kart Silindi: {part.get('name') or ''}",
            "created_at": now.isoformat(timespec="seconds"),
            "is_deleted": 0,
        })
        finance_id = None
        refund = stock * purchase_price
        rate = resolve_exchange_rate(conn, currency) if refund else 1.0
        if refund > 0:
            finance_id = insert_available(conn, "accounting", {
                "type": "Gelir",
                "category": "Stok İptali / Silinme",
                "amount": refund,
                "try_equivalent": round(refund * rate, 4),
                "currency": currency,
                "exchange_rate": rate,
                "original_amount": refund,
                "description": f"Stok Kartı Silinme İadesi: {stock:g} x {part.get('name') or ''}",
                "date": now.strftime("%Y-%m-%d"),
                "created_at": now.isoformat(timespec="seconds"),
                "payment_method": "Mahsup",
                "ref_no": f"WEB-STOCK-DELETE-{part_id}",
                "product_service_id": part_id,
                "product_service_type": "stock",
                "is_deleted": 0,
            })
        columns = set(table_columns(conn, "parts"))
        if "deleted_at" in columns:
            conn.execute("UPDATE parts SET is_deleted=1,deleted_at=? WHERE id=?", (now.isoformat(timespec="seconds"), part_id))
        else:
            conn.execute("UPDATE parts SET is_deleted=1 WHERE id=?", (part_id,))
        conn.commit()
    conn.close()
    return {
        "ok": True,
        "id": part_id,
        "movement_id": movement_id,
        "finance_id": finance_id,
        "refund": refund,
        "currency": currency,
        "stock": stock,
        "purchase_price": purchase_price,
        "exchange_rate": rate,
        "try_equivalent": round(refund * rate, 4),
    }


def desktop_bootstrap() -> dict:
    with db_connect() as conn:
        customers = rows(conn, "SELECT * FROM customers WHERE COALESCE(is_deleted,0)=0 ORDER BY id DESC")
        balances = rows(conn, "SELECT customer_id,currency,balance FROM customer_currency_balances")
        balance_map: dict[int, dict[str, float]] = {}
        for item in balances:
            balance_map.setdefault(item["customer_id"], {"TRY": 0, "USD": 0, "EUR": 0})[item["currency"]] = item["balance"] or 0
        for customer in customers:
            customer["balances"] = balance_map.get(customer["id"], {"TRY": 0, "USD": 0, "EUR": 0})
            customer["services"] = []
            customer["quotes"] = []
        by_id = {customer["id"]: customer for customer in customers}
        devices = rows(conn, "SELECT * FROM devices WHERE COALESCE(is_deleted,0)=0 ORDER BY id DESC")
        used_part_rows = rows(conn, "SELECT * FROM used_parts WHERE COALESCE(is_deleted,0)=0 ORDER BY id DESC")
        parts_by_tracking: dict[str, list[dict]] = {}
        for used_part in used_part_rows:
            parts_by_tracking.setdefault(str(used_part.get("tracking_no") or ""), []).append(used_part)
        for device in devices:
            customer = by_id.get(device.get("customer_id"))
            if customer:
                service_currency = scalar(
                    conn,
                    "SELECT currency FROM currency_transactions WHERE tracking_no=? AND transaction_type='DEBIT' ORDER BY id DESC LIMIT 1",
                    (str(device.get("tracking_no") or ""),),
                    "TRY",
                ) or "TRY"
                customer["services"].append({
                    "id": device.get("id"),
                    "date": device.get("entry_date") or device.get("created_at") or "",
                    "no": device.get("tracking_no") or f'SRV-{device.get("id")}',
                    "device": " ".join(filter(None, [device.get("device_brand"), device.get("device_model")])) or device.get("device_type") or "Cihaz",
                    "device_type": device.get("device_type") or "Cihaz",
                    "brand": device.get("device_brand") or "",
                    "model": device.get("device_model") or "",
                    "serial": device.get("serial_no") or "",
                    "status": device.get("status") or "Bekliyor",
                    "approval_status": device.get("approval_status") or "",
                    "note": device.get("fault_description") or "",
                    "internal_notes": device.get("internal_notes") or "",
                    "repair_details": device.get("repair_details") or "",
                    "technician": device.get("technician") or "",
                    "labor_cost": device.get("labor_cost") or 0,
                    "cargo_fee": device.get("cargo_fee") or 0,
                    "delivery_type": device.get("delivery_type") or "",
                    "warranty_status": device.get("warranty_status") or "Yok",
                    "warranty_end_date": device.get("warranty_end_date") or "",
                    "accessories": device.get("accessories") or "",
                    "amount": device.get("price") or 0,
                    "currency": str(service_currency).upper(),
                    "delivery": device.get("estimated_date") or device.get("exit_date") or device.get("delivered_at") or "",
                    "service": device.get("service_source") or "Servis",
                    "priority": device.get("priority") or device.get("urgency") or "Normal",
                    "payment_status": device.get("payment_status") or "Beklemede",
                    "used_parts": parts_by_tracking.get(str(device.get("tracking_no") or ""), []),
                })
        offers = rows(conn, "SELECT * FROM offers ORDER BY id DESC")
        offer_items = rows(conn, "SELECT * FROM offer_items ORDER BY id")
        items_by_offer: dict[int, list[dict]] = {}
        for item in offer_items:
            try:
                payload = json.loads(item.get("payload_json") or "{}")
            except (TypeError, ValueError):
                payload = {}
            normalized = dict(item)
            normalized.update({key: value for key, value in payload.items() if key not in normalized or normalized.get(key) in (None, "")})
            normalized["name"] = normalized.get("service") or normalized.get("description") or "Ürün / Hizmet"
            normalized["price"] = normalized.get("unit_price") or 0
            items_by_offer.setdefault(item.get("offer_id"), []).append(normalized)
        for offer in offers:
            offer["items"] = items_by_offer.get(offer.get("id"), [])
            offer["no"] = offer.get("offer_no")
            offer["customerId"] = offer.get("customer_id")
            offer["date"] = offer.get("created_at") or ""
            customer = by_id.get(offer.get("customer_id"))
            if customer:
                customer_offer = dict(offer)
                customer_offer["total"] = offer.get("total_try") or offer.get("total") or 0
                customer_offer["status"] = offer.get("status") or "Teklif"
                customer["quotes"].append(customer_offer)
        stock = rows(conn, "SELECT * FROM parts WHERE COALESCE(is_deleted,0)=0 ORDER BY id DESC")
        movements = rows(conn, "SELECT sm.*,p.name product FROM stock_movements sm LEFT JOIN parts p ON p.id=sm.part_id WHERE COALESCE(sm.is_deleted,0)=0 ORDER BY sm.id DESC LIMIT 500")
        finance = rows(conn, "SELECT * FROM accounting WHERE COALESCE(is_deleted,0)=0 ORDER BY date DESC,id DESC LIMIT 1000")
        appointments = rows(conn, "SELECT * FROM appointments ORDER BY date DESC,time DESC LIMIT 1000")
        scheduled_alerts = rows(conn, "SELECT * FROM scheduled_alerts WHERE COALESCE(is_enabled,1)=1 ORDER BY trigger_time")
        personnel = rows(conn, "SELECT id,name,role,department,active FROM personnel WHERE COALESCE(active,1)=1 ORDER BY name")
        raw_settings = {row["key"]: row["value"] for row in rows(conn, "SELECT key,value FROM settings")}
        sensitive = re.compile(r"(password|pass$|token|api_key|secret|security_answer_hash)", re.I)
        settings = {key: ("" if sensitive.search(key) else value) for key, value in raw_settings.items()}
        settings_configured = [key for key, value in raw_settings.items() if value and sensitive.search(key)]
        internal_settings = {row["key"]: row["value"] for row in rows(conn, "SELECT key,value FROM internal_settings")}
        current_sector = internal_settings.get("current_sector") or raw_settings.get("current_sector") or "teknik_servis"
        if current_sector not in {"teknik_servis", "otomotiv"}:
            current_sector = "teknik_servis"
        return {
            "database": str(active_db_path()), "tenant_id": active_tenant_id(), "company_name": active_company_name(), "customers": customers, "stock": stock, "devices": devices,
            "movements": movements, "finance": finance, "appointments": appointments,
            "offers": offers, "scheduled_alerts": scheduled_alerts, "personnel": personnel,
            "used_parts": used_part_rows, "exchange_rates": exchange_rates(refresh=False), "settings": settings,
            "settings_configured": settings_configured,
            "internal_settings": internal_settings, "current_sector": current_sector, "counts": {
                "customers": len(customers), "services": len(devices), "stock": len(stock),
                "appointments": len(appointments), "offers": len(offers),
            },
        }


SYNC_EXCLUDED_TABLES = {"users", "web_sessions", "tenants", "sync_events"}
SYNC_TABLES = TABLES - SYNC_EXCLUDED_TABLES


def sync_manifest() -> dict:
    tenant_id = active_tenant_id()
    if not tenant_id:
        raise PermissionError("Senkronizasyon için firma oturumu gerekiyor.")
    result = {"ok": True, "tenant_id": tenant_id, "company_name": active_company_name(), "tables": {}}
    with closing(db_connect()) as conn:
        for table in sorted(SYNC_TABLES):
            if not scalar(conn, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?", (table,)):
                continue
            columns = table_columns(conn, table)
            item = {"count": int(scalar(conn, f'SELECT COUNT(*) FROM "{table}"', default=0)), "columns": columns}
            if "id" in columns:
                item["last_id"] = int(scalar(conn, f'SELECT COALESCE(MAX(id),0) FROM "{table}"', default=0) or 0)
            for timestamp in ("updated_at", "created_at", "date"):
                if timestamp in columns:
                    item["last_timestamp"] = scalar(conn, f'SELECT MAX("{timestamp}") FROM "{table}"', default="") or ""
                    break
            result["tables"][table] = item
    tenant = tenant_by_id(tenant_id) or {}
    result["db_filename"] = tenant.get("db_filename", "")
    return result


def sync_pull(body: dict) -> dict:
    tables = body.get("tables") or sorted(SYNC_TABLES)
    if not isinstance(tables, list):
        raise ValueError("Senkronizasyon tablo listesi geçersiz.")
    since = body.get("since") or {}
    limit = min(max(int(body.get("limit") or 5000), 1), 5000)
    changes: dict[str, list[dict]] = {}
    with closing(db_connect()) as conn:
        for table in tables:
            if table not in SYNC_TABLES or not scalar(conn, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?", (table,)):
                continue
            columns = table_columns(conn, table)
            marker = since.get(table, "") if isinstance(since, dict) else ""
            where, params = "", []
            if "id" in columns and str(marker).isdigit():
                where, params = " WHERE id>?", [int(marker)]
            elif marker:
                timestamp = next((name for name in ("updated_at", "created_at", "date") if name in columns), None)
                if timestamp:
                    where, params = f' WHERE COALESCE("{timestamp}",\'\')>?', [str(marker)]
            order = " ORDER BY id ASC" if "id" in columns else ""
            changes[table] = rows(conn, f'SELECT * FROM "{table}"{where}{order} LIMIT ?', (*params, limit))
    return {"ok": True, "tenant_id": active_tenant_id(), "changes": changes}


def sync_push(body: dict) -> dict:
    changes = body.get("changes") or []
    if isinstance(changes, dict):
        changes = [{"table": table, "row": row, "action": "upsert"} for table, items in changes.items() for row in (items if isinstance(items, list) else [items])]
    if not isinstance(changes, list) or len(changes) > 5000:
        raise ValueError("Senkronizasyon değişiklik paketi geçersiz veya çok büyük.")
    applied = skipped = 0
    errors: list[str] = []
    with closing(db_connect()) as conn:
        conn.execute("PRAGMA foreign_keys=OFF")
        for change in changes:
            if not isinstance(change, dict) or change.get("table") not in SYNC_TABLES:
                errors.append("İzin verilmeyen tablo")
                continue
            table = str(change["table"])
            row = dict(change.get("row") or {})
            action = str(change.get("action") or "upsert").lower()
            source_id = str(change.get("source_id") or f"{table}:{row.get('id','')}:{action}:{hashlib.sha1(json.dumps(row, sort_keys=True, default=str).encode()).hexdigest()[:16]}")
            record_id = str(row.get("id") or "")
            try:
                duplicate = conn.execute(
                    "SELECT 1 FROM sync_events WHERE source_id=? AND table_name=? AND COALESCE(record_id,'')=? AND action=?",
                    (source_id, table, record_id, action),
                ).fetchone()
                if duplicate:
                    skipped += 1
                    continue
                columns = table_columns(conn, table)
                if action == "delete" and row.get("id") is not None:
                    if "is_deleted" in columns:
                        conn.execute(f'UPDATE "{table}" SET is_deleted=1 WHERE id=?', (row["id"],))
                    else:
                        conn.execute(f'DELETE FROM "{table}" WHERE id=?', (row["id"],))
                else:
                    clean = {key: value for key, value in row.items() if key in columns}
                    if not clean:
                        raise ValueError("Boş kayıt")
                    if "id" in columns and clean.get("id") is not None:
                        existing = conn.execute(f'SELECT * FROM "{table}" WHERE id=?', (clean["id"],)).fetchone()
                        if existing and "updated_at" in columns and clean.get("updated_at") and existing["updated_at"] and str(clean["updated_at"]) <= str(existing["updated_at"]):
                            skipped += 1
                            continue
                        if existing:
                            updates = {key: value for key, value in clean.items() if key != "id"}
                            if updates:
                                setters = ",".join(f'"{key}"=?' for key in updates)
                                conn.execute(f'UPDATE "{table}" SET {setters} WHERE id=?', (*updates.values(), clean["id"]))
                        else:
                            names = ",".join(f'"{key}"' for key in clean)
                            marks = ",".join("?" for _ in clean)
                            conn.execute(f'INSERT INTO "{table}" ({names}) VALUES ({marks})', tuple(clean.values()))
                    else:
                        names = ",".join(f'"{key}"' for key in clean)
                        marks = ",".join("?" for _ in clean)
                        conn.execute(f'INSERT INTO "{table}" ({names}) VALUES ({marks})', tuple(clean.values()))
                conn.execute(
                    "INSERT OR IGNORE INTO sync_events(source_id,table_name,record_id,action,payload_hash,created_at) VALUES (?,?,?,?,?,?)",
                    (source_id, table, record_id, action, hashlib.sha256(json.dumps(row, sort_keys=True, default=str).encode()).hexdigest(), utc_now().isoformat(timespec="seconds")),
                )
                applied += 1
            except Exception as error:
                errors.append(f"{table}: {error}")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.commit()
    return {"ok": not errors, "tenant_id": active_tenant_id(), "applied": applied, "skipped": skipped, "errors": errors}


class AYECRequestHandler(BaseHTTPRequestHandler):
    server_version = "AYECProWeb/2.0"

    def log_message(self, _format, *_args):
        return

    def session_token(self) -> str:
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
            return cookie[SESSION_COOKIE].value if SESSION_COOKIE in cookie else ""
        except Exception:
            return ""

    def current_user(self) -> dict | None:
        if not hasattr(self, "_current_user_cache"):
            self._current_user_cache = session_user(self.session_token())
        return self._current_user_cache

    def client_ip(self) -> str:
        forwarded = self.headers.get("X-Forwarded-For", "").split(",", 1)[0].strip()
        return forwarded or self.client_address[0]

    def session_cookie_header(self, token: str, max_age: int = 0, remember: bool = False) -> str:
        value = f"{SESSION_COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax"
        if remember and max_age > 0:
            value += f"; Max-Age={max_age}"
        if not token:
            value += "; Max-Age=0"
        secure = setting_bool(os.environ.get("AYEC_COOKIE_SECURE")) or self.headers.get("X-Forwarded-Proto", "").lower() == "https"
        if secure:
            value += "; Secure"
        return value

    def same_origin(self) -> bool:
        origin = self.headers.get("Origin", "").strip()
        if not origin:
            return True
        return urlparse(origin).netloc.lower() == self.headers.get("Host", "").lower()

    def _headers(self, status: int, content_type: str, length: int, extra_headers: dict | None = None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'")
        self.send_header("Cache-Control", "no-store")
        for name, value in (extra_headers or {}).items():
            self.send_header(name, value)
        self.end_headers()

    def send_json(self, data, status=200, headers: dict | None = None):
        payload = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
        self._headers(status, "application/json; charset=utf-8", len(payload), headers)
        self.wfile.write(payload)

    def send_bytes(self, payload: bytes, content_type: str, status=200, disposition: str | None = None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Cache-Control", "no-store")
        if disposition:
            self.send_header("Content-Disposition", disposition)
        self.end_headers()
        self.wfile.write(payload)

    def read_json(self):
        size = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(size).decode("utf-8")) if size else {}

    def do_GET(self):
        try:
            clear_tenant_context()
            parsed = urlparse(self.path)
            path = unquote(parsed.path)
            query = parse_qs(parsed.query)
            if path == "/api/auth/status":
                return self.send_json(auth_status(self.session_token()))
            if path == "/api/desktop/health":
                try:
                    with closing(db_connect()) as conn:
                        available = {
                            row[0]
                            for row in conn.execute(
                                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                            )
                        }
                    missing = sorted(REQUIRED_OPERATIONAL_TABLES - available)
                    return self.send_json({
                        "ok": not missing,
                        "service": "AYEC Pro Web",
                        "schema_ready": not missing,
                        "missing_tables": missing,
                    }, 200 if not missing else 503)
                except Exception as error:
                    return self.send_json({"ok": False, "service": "AYEC Pro Web", "error": str(error)}, 503)
            if path.startswith("/api/") and not self.current_user():
                return self.send_json({"error": "Oturum açmanız gerekiyor.", "code": "AUTH_REQUIRED"}, 401)
            if path == "/api/control/overview":
                try:
                    return self.send_json(control_overview(self.current_user()))
                except PermissionError as error:
                    return self.send_json({"error": str(error)}, 403)
            if path == "/api/sync/manifest":
                return self.send_json(sync_manifest())
            if path == "/api/sync/pull":
                return self.send_json(sync_pull({"tables": query.get("table") or None, "since": {}}))
            if path == "/api/desktop/bootstrap":
                payload = desktop_bootstrap()
                payload["current_user"] = public_user(self.current_user())
                return self.send_json(payload)
            if path == "/api/desktop/exchange-rates":
                return self.send_json({"ok": True, "rates": exchange_rates(refresh=query.get("refresh", ["1"])[0] != "0")})
            if path == "/api/desktop/dialogs":
                data = json.loads(DIALOGS_MANIFEST.read_text(encoding="utf-8")) if DIALOGS_MANIFEST.exists() else {"summary": {}, "dialogs": []}
                return self.send_json(data)
            if path == "/api/desktop/company-logo":
                with db_connect() as conn:
                    logo_path = scalar(conn, "SELECT value FROM settings WHERE key='logo_path'", default="")
                logo = resolve_logo_path(logo_path)
                if not logo:
                    return self.send_json({"error": "Firma logosu ayarlanmamış"}, 404)
                content_type = mimetypes.guess_type(logo.name)[0] or "application/octet-stream"
                if content_type not in {"image/png", "image/jpeg", "image/webp"}:
                    return self.send_json({"error": "Firma logosu desteklenmeyen biçimde"}, 415)
                return self.send_bytes(logo.read_bytes(), content_type)
            if path.startswith("/api/desktop/proforma/"):
                offer_text = path.rsplit("/", 1)[-1]
                if not offer_text.isdigit():
                    return self.send_json({"error": "Geçersiz teklif numarası"}, 400)
                template = query.get("template", [None])[0]
                target, offer_no = build_offer_pdf(int(offer_text), template)
                try:
                    payload = target.read_bytes()
                finally:
                    target.unlink(missing_ok=True)
                mode = "attachment" if query.get("download", ["0"])[0] == "1" else "inline"
                safe_name = re.sub(r"[^A-Za-z0-9_-]+", "-", offer_no).strip("-") or "proforma"
                return self.send_bytes(payload, "application/pdf", disposition=f'{mode}; filename="{safe_name}.pdf"')
            if path.startswith("/api/desktop/table/"):
                table = path.rsplit("/", 1)[-1]
                if table not in TABLES:
                    return self.send_json({"error": "Tablo izinli değil"}, 404)
                request_user = self.current_user()
                if table == "users" and not role_is_admin(request_user.get("role")):
                    return self.send_json({"error": "Kullanıcı yönetimi için yönetici yetkisi gerekiyor."}, 403)
                limit = min(max(int(query.get("limit", [100])[0]), 1), 1000)
                q = query.get("q", [""])[0].strip()
                with db_connect() as conn:
                    if not scalar(conn, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?", (table,)):
                        return self.send_json({"table": table, "columns": [], "rows": [], "count": 0, "available": False})
                    columns = table_columns(conn, table)
                    where, params = "", []
                    if "is_deleted" in columns:
                        where = " WHERE COALESCE(is_deleted,0)=0"
                    if q:
                        searchable = [c for c in columns if c not in {"id", "is_deleted"}][:12]
                        prefix = " AND " if where else " WHERE "
                        where += prefix + "(" + " OR ".join(f'CAST("{c}" AS TEXT) LIKE ?' for c in searchable) + ")"
                        params.extend([f"%{q}%"] * len(searchable))
                    order = " ORDER BY id DESC" if "id" in columns else ""
                    data = rows(conn, f'SELECT * FROM "{table}"{where}{order} LIMIT ?', (*params, limit))
                    if table == "settings":
                        sensitive = re.compile(r"(password|pass$|token|api_key|secret|security_answer_hash)", re.I)
                        for item in data:
                            if sensitive.search(str(item.get("key", ""))):
                                item["value"] = ""
                    if table == "users":
                        private_columns = {
                            "password", "remember_token", "secret_answer", "security_answer_hash",
                            "reset_token", "reset_token_expires",
                        }
                        columns = [column for column in columns if column not in private_columns]
                        data = [
                            {key: value for key, value in item.items() if key not in private_columns}
                            for item in data
                        ]
                    return self.send_json({"table": table, "columns": columns, "rows": data, "count": len(data)})
            requested = path
            target = (WEB_ROOT / requested.lstrip("/")).resolve()
            if requested == "/" or not target.exists() or (target != WEB_ROOT and WEB_ROOT not in target.parents):
                target = WEB_ROOT / "index.html"
            payload = target.read_bytes()
            content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
            if content_type.startswith("text/") or content_type == "application/javascript":
                content_type += "; charset=utf-8"
            self._headers(200, content_type, len(payload))
            self.wfile.write(payload)
        except Exception as exc:
            (ROOT / ".ayec-handler-error.log").write_text(traceback.format_exc(), encoding="utf-8")
            self.send_json({"error": str(exc)}, 500)

    def do_POST(self):
        try:
            clear_tenant_context()
            path = unquote(urlparse(self.path).path)
            if path == "/api/auth/setup":
                try:
                    result = setup_application(self.read_json())
                    return self.send_json(result, 201)
                except PermissionError as error:
                    return self.send_json({"error": str(error)}, 409)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/auth/register":
                try:
                    body = self.read_json()
                    existing_user = self.current_user()
                    result = register_account(body, (existing_user or {}).get("_tenant_id"))
                    return self.send_json(result, 201)
                except PermissionError as error:
                    return self.send_json({"error": str(error)}, 403)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/auth/company":
                try:
                    return self.send_json(setup_application(self.read_json(), allow_existing=True), 201)
                except PermissionError as error:
                    return self.send_json({"error": str(error)}, 409)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/auth/login":
                client_key = self.client_ip()
                if auth_rate_limited(client_key):
                    return self.send_json({"error": "Çok fazla başarısız deneme. 15 dakika sonra tekrar deneyin."}, 429)
                body = self.read_json()
                user = authenticate_account(
                    str(body.get("identifier") or ""),
                    str(body.get("password") or ""),
                    str(body.get("tenant_id") or "") or None,
                )
                if not user:
                    record_auth_failure(client_key)
                    return self.send_json({"error": "Kullanıcı adı/e-posta veya parola hatalı."}, 401)
                clear_auth_failures(client_key)
                remember = bool(body.get("remember"))
                token, max_age = create_session(
                    int(user["id"]), remember, self.headers.get("User-Agent", ""), self.client_ip(), user.get("_tenant_id")
                )
                return self.send_json(
                    {"ok": True, "user": public_user(user)},
                    headers={"Set-Cookie": self.session_cookie_header(token, max_age, remember)},
                )
            if path == "/api/auth/logout":
                delete_session(self.session_token())
                return self.send_json(
                    {"ok": True}, headers={"Set-Cookie": self.session_cookie_header("")}
                )

            user = self.current_user()
            if not user:
                return self.send_json({"error": "Oturum açmanız gerekiyor.", "code": "AUTH_REQUIRED"}, 401)
            if not self.same_origin():
                return self.send_json({"error": "İstek kaynağı doğrulanamadı."}, 403)
            if path == "/api/control/tenant":
                try:
                    return self.send_json(control_update_tenant(user, self.read_json()))
                except PermissionError as error:
                    return self.send_json({"error": str(error)}, 403)
                except LookupError as error:
                    return self.send_json({"error": str(error)}, 404)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/control/user":
                try:
                    return self.send_json(control_update_user(user, self.read_json()))
                except PermissionError as error:
                    return self.send_json({"error": str(error)}, 403)
                except LookupError as error:
                    return self.send_json({"error": str(error)}, 404)
                except (ValueError, sqlite3.IntegrityError) as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/sync/push":
                try:
                    return self.send_json(sync_push(self.read_json()))
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/sync/pull":
                return self.send_json(sync_pull(self.read_json()))
            if path == "/api/admin/wipe-user-data":
                body = self.read_json()
                try:
                    return self.send_json(wipe_user_data(user, str(body.get("password") or ""), str(body.get("phrase") or "")))
                except PermissionError as error:
                    return self.send_json({"error": str(error)}, 403)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/desktop/company-logo":
                if not role_is_admin(user.get("role")):
                    return self.send_json({"error": "Firma ayarları için yönetici yetkisi gerekiyor."}, 403)
                body = self.read_json()
                if body.get("remove"):
                    with db_connect() as conn:
                        conn.execute("INSERT INTO settings (key,value) VALUES ('logo_path','') ON CONFLICT(key) DO UPDATE SET value='' ")
                        conn.commit()
                    return self.send_json({"ok": True, "path": "", "url": ""})
                payload = base64.b64decode(body.get("data", ""), validate=True)
                if not payload or len(payload) > 5 * 1024 * 1024:
                    return self.send_json({"error": "Logo boş veya 5 MB sınırını aşıyor"}, 413)
                if payload.startswith(b"\x89PNG\r\n\x1a\n"):
                    extension = ".png"
                elif payload.startswith(b"\xff\xd8\xff"):
                    extension = ".jpg"
                elif payload.startswith(b"RIFF") and payload[8:12] == b"WEBP":
                    extension = ".webp"
                else:
                    return self.send_json({"error": "Yalnızca PNG, JPG veya WEBP logo yüklenebilir"}, 415)
                upload_dir = WEB_ROOT / "uploads"
                upload_dir.mkdir(parents=True, exist_ok=True)
                target = upload_dir / f"company-logo-{datetime.now().strftime('%Y%m%d%H%M%S%f')}{extension}"
                target.write_bytes(payload)
                stored_path = target.relative_to(ROOT).as_posix()
                with db_connect() as conn:
                    conn.execute(
                        "INSERT INTO settings (key,value) VALUES ('logo_path',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                        (stored_path,),
                    )
                    conn.commit()
                return self.send_json({"ok": True, "path": stored_path, "url": "/api/desktop/company-logo"})
            if path == "/api/desktop/customer/payment":
                exchange_rates(refresh=True)
                try:
                    return self.send_json(record_customer_payment(self.read_json()))
                except LookupError as error:
                    return self.send_json({"error": str(error)}, 404)
                except ValueError as error:
                    return self.send_json({"error": str(error)}, 400)
            if path == "/api/desktop/stock/delete":
                body = self.read_json()
                part_id = int(body.get("id") or 0)
                if not part_id:
                    return self.send_json({"error": "Geçersiz stok kartı"}, 400)
                try:
                    return self.send_json(delete_stock_with_reversal(part_id))
                except LookupError as error:
                    return self.send_json({"error": str(error)}, 404)
            if path == "/api/desktop/stock/save":
                exchange_rates(refresh=True)
                try:
                    return self.send_json(save_stock_card(self.read_json()))
                except LookupError as error:
                    return self.send_json({"error": str(error)}, 404)
            if path == "/api/desktop/sales/commit":
                exchange_rates(refresh=True)
                try:
                    return self.send_json(commit_sales_hub(self.read_json()))
                except LookupError as error:
                    return self.send_json({"error": str(error)}, 404)
            if path == "/api/desktop/technician/update":
                exchange_rates(refresh=True)
                try:
                    return self.send_json(update_technician_job(self.read_json()))
                except LookupError as error:
                    return self.send_json({"error": str(error)}, 404)
            if path == "/api/desktop/smart-import":
                try:
                    body = self.read_json()
                    payload = base64.b64decode(body.get("data", ""), validate=True)
                    if not payload:
                        return self.send_json({"error": "İçe aktarılacak dosya boş"}, 400)
                    if len(payload) > 25 * 1024 * 1024:
                        return self.send_json({"error": "Dosya 25 MB sınırını aşıyor"}, 413)
                    return self.send_json(smart_import(body.get("name", "belge"), payload))
                except (ValueError, json.JSONDecodeError) as error:
                    return self.send_json({"error": f"İçe aktarma verisi geçersiz: {error}"}, 400)
                except Exception as error:
                    (ROOT / ".ayec-import-error.log").write_text(traceback.format_exc(), encoding="utf-8")
                    return self.send_json({"error": f"Akıllı içe aktarma başarısız: {error}"}, 500)
            if not path.startswith("/api/desktop/table/"):
                return self.send_json({"error": "Endpoint bulunamadı"}, 404)
            table = path.rsplit("/", 1)[-1]
            if table not in TABLES:
                return self.send_json({"error": "Tablo izinli değil"}, 404)
            if table in {"users", "settings", "internal_settings"} and not role_is_admin(user.get("role")):
                return self.send_json({"error": "Bu ayarı değiştirmek için yönetici yetkisi gerekiyor."}, 403)
            body = self.read_json()
            if (
                table == "internal_settings"
                and str(body.get("key") or "") == "current_sector"
            ):
                return self.send_json(
                    {"error": "Sector can only be changed from the platform management panel"},
                    403,
                )
            action = body.pop("_action", "insert")
            row_id = body.pop("id", None)
            with db_connect() as conn:
                if not scalar(conn, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?", (table,)):
                    return self.send_json({"error": "Masaüstü veritabanında bu modül tablosu henüz oluşturulmamış"}, 404)
                columns = table_columns(conn, table)
                clean = {
                    k: v
                    for k, v in body.items()
                    if k in columns and k not in {"id", "password", "remember_token"}
                }
                if table in {"settings", "internal_settings"} and "key" in body:
                    conn.execute(
                        f'INSERT INTO "{table}" (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                        (body["key"], str(body.get("value", ""))),
                    )
                    conn.commit()
                    return self.send_json({"ok": True, "id": body["key"], "action": "upsert"})
                if action == "delete" and row_id is not None:
                    if "is_deleted" in columns:
                        conn.execute(f'UPDATE "{table}" SET is_deleted=1 WHERE id=?', (row_id,))
                    else:
                        conn.execute(f'DELETE FROM "{table}" WHERE id=?', (row_id,))
                elif action == "update" and row_id is not None:
                    sets = ",".join(f'"{k}"=?' for k in clean)
                    conn.execute(f'UPDATE "{table}" SET {sets} WHERE id=?', (*clean.values(), row_id))
                else:
                    if "created_at" in columns and "created_at" not in clean:
                        clean["created_at"] = datetime.now().isoformat(timespec="seconds")
                    names = ",".join(f'"{k}"' for k in clean)
                    marks = ",".join("?" for _ in clean)
                    cur = conn.execute(f'INSERT INTO "{table}" ({names}) VALUES ({marks})', tuple(clean.values()))
                    row_id = cur.lastrowid
                    if table == "devices" and str(clean.get("service_source") or "") == "Web Otomotiv":
                        plate = str(
                            clean.get("vehicle_plate")
                            or clean.get("serial_no")
                            or ""
                        ).strip().upper()
                        vehicle_id = None
                        if plate:
                            vehicle_id = scalar(
                                conn,
                                "SELECT id FROM customer_vehicles WHERE UPPER(TRIM(plate))=?",
                                (plate,),
                                default=0,
                            )
                            if not vehicle_id:
                                vehicle_id = insert_available(
                                    conn,
                                    "customer_vehicles",
                                    {
                                        "customer_id": clean.get("customer_id"),
                                        "plate": plate,
                                        "brand": clean.get("device_brand"),
                                        "model": clean.get("device_model"),
                                        "last_known_odometer": 0,
                                        "is_active": 1,
                                        "created_at": clean.get("created_at"),
                                        "updated_at": clean.get("created_at"),
                                    },
                                )
                        insert_available(
                            conn,
                            "automotive_service_forms",
                            {
                                "device_id": row_id,
                                "tracking_no": clean.get("tracking_no"),
                                "vehicle_id": vehicle_id,
                                "created_at": clean.get("created_at"),
                                "updated_at": clean.get("created_at"),
                            },
                        )
                        insert_available(
                            conn,
                            "vehicle_maintenance_cards",
                            {
                                "vehicle_id": vehicle_id,
                                "customer_id": clean.get("customer_id"),
                                "customer_name": clean.get("customer_name"),
                                "vehicle_plate": plate,
                                "vehicle_brand": clean.get("device_brand"),
                                "vehicle_model": clean.get("device_model"),
                                "service_date": clean.get("entry_date"),
                                "next_maintenance_date": clean.get("estimated_date"),
                                "notes": clean.get("fault_description"),
                                "linked_device_tracking_no": clean.get("tracking_no"),
                                "linked_device_id": row_id,
                                "created_by": "Web",
                                "created_at": clean.get("created_at"),
                                "updated_at": clean.get("created_at"),
                            },
                        )
                conn.commit()
            return self.send_json({"ok": True, "id": row_id, "action": action})
        except Exception as exc:
            (ROOT / ".ayec-handler-error.log").write_text(traceback.format_exc(), encoding="utf-8")
            self.send_json({"error": str(exc)}, 400)


def main() -> None:
    global DB_PATH, TENANT_ROOT
    parser = argparse.ArgumentParser(description="AYEC Pro web arayuzu")
    parser.add_argument("--host", default=os.environ.get("AYEC_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("AYEC_PORT", "8501")))
    parser.add_argument("--db", default=str(DB_PATH), help="SQLite veritabanı dosyası")
    parser.add_argument("--tenant-dir", default=str(TENANT_ROOT), help="Firma SQLite dosyalarının klasörü")
    args = parser.parse_args()
    DB_PATH = Path(args.db).expanduser().resolve()
    TENANT_ROOT = Path(args.tenant_dir).expanduser().resolve()
    mimetypes.add_type("application/javascript", ".js")
    server = ThreadingHTTPServer((args.host, args.port), AYECRequestHandler)
    print(f"AYEC Pro hazır: http://127.0.0.1:{args.port} | Veritabanı: {DB_PATH}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
